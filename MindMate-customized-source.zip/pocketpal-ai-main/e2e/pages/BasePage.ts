/**
 * Base Page Object class
 * Contains common methods and wait utilities for all pages
 */

declare const browser: WebdriverIO.Browser;

export type ChainableElement = ReturnType<WebdriverIO.Browser['$']>;

export abstract class BasePage {
  protected static readonly DEFAULT_TIMEOUT = 10000;

  /**
   * Wait for an element to be displayed and return it
   */
  protected async waitForElement(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<ChainableElement> {
    const element = browser.$(selector);
    await element.waitForDisplayed({timeout});
    return element;
  }

  /**
   * Wait for an element to exist in DOM (may not be visible)
   */
  protected async waitForExist(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<ChainableElement> {
    const element = browser.$(selector);
    await element.waitForExist({timeout});
    return element;
  }

  /**
   * Check if element is displayed within timeout
   */
  protected async isElementDisplayed(
    selector: string,
    timeout = 3000,
  ): Promise<boolean> {
    try {
      const element = browser.$(selector);
      await element.waitForDisplayed({timeout});
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Wait for element to disappear
   */
  protected async waitForElementToDisappear(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<void> {
    const element = browser.$(selector);
    await element.waitForDisplayed({timeout, reverse: true});
  }

  /**
   * Wait for an element to be displayed and enabled
   */
  protected async waitForEnabled(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<ChainableElement> {
    const element = browser.$(selector);
    await element.waitForDisplayed({timeout});
    await element.waitForEnabled({timeout});
    return element;
  }

  /**
   * Tap on an element
   */
  protected async tap(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<void> {
    const element = await this.waitForElement(selector, timeout);
    await element.click();
  }

  /**
   * Type text into an input field
   */
  protected async typeText(
    selector: string,
    text: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<void> {
    const element = await this.waitForElement(selector, timeout);
    await element.clearValue();
    await element.setValue(text);
  }

  /**
   * Dismiss keyboard if visible
   *
   * Note: On iOS, hideKeyboard() is unreliable due to XCTest limitations.
   * We tap the Return/Done key on the keyboard instead.
   * See: https://github.com/appium/appium/issues/17550
   */
  protected async dismissKeyboard(): Promise<void> {
    const isIOS = (browser as unknown as {isIOS?: boolean}).isIOS;

    if (isIOS) {
      // Check if keyboard is actually shown; skip if not
      const isShown = await (
        browser as unknown as {isKeyboardShown: () => Promise<boolean>}
      )
        .isKeyboardShown()
        .catch(() => false);
      if (!isShown) {
        return;
      }

      // iOS: Try Return/Done/Search key first (standard text keyboards)
      const keyboardKey = browser.$(
        '-ios predicate string:name == "Return" OR name == "Done" OR name == "Search"',
      );
      if (await keyboardKey.isExisting()) {
        await keyboardKey.click();
        await browser.pause(200);
      } else {
        // Numeric keyboards have no Return/Done key.
        // Tap the sheet/screen content area to blur the input.
        // Use 40% from top to stay well inside a bottom sheet
        // (avoids close button at top and keyboard at bottom).
        const {width, height} = await (
          browser as unknown as {
            getWindowSize: () => Promise<{width: number; height: number}>;
          }
        ).getWindowSize();
        await browser
          .action('pointer', {parameters: {pointerType: 'touch'}})
          .move({x: Math.floor(width / 2), y: Math.floor(height * 0.4)})
          .down()
          .up()
          .perform();
        await browser.pause(300);
      }
    } else {
      // Android: ESC hides the keyboard without emitting a back event, but
      // some Gboard builds (Android 11/14 phones) ignore it. Back is the
      // fallback only while the keyboard is verifiably up: the IME consumes
      // it then, whereas a back with no keyboard pops the screen behind a sheet.
      const driver = browser as unknown as {
        isKeyboardShown: () => Promise<boolean>;
        pressKeyCode: (code: number) => Promise<void>;
      };
      const isShown = () => driver.isKeyboardShown().catch(() => false);
      const hidden = () =>
        browser
          .waitUntil(async () => !(await isShown()), {
            timeout: 1500,
            interval: 250,
          })
          .then(() => true)
          .catch(() => false);
      for (const keyCode of [111, 4]) {
        if (!(await isShown())) {
          return;
        }
        await driver.pressKeyCode(keyCode).catch(() => undefined);
        if (await hidden()) {
          return;
        }
      }
      throw new Error('Android soft keyboard still shown after ESC and Back');
    }
  }

  /**
   * Get element by selector for use with expect matchers
   */
  protected getElement(selector: string): ChainableElement {
    return browser.$(selector);
  }

  /**
   * Find the last displayed element matching the selector
   * Useful when multiple elements match (e.g., stacked sheets) and you want the topmost/visible one
   */
  protected async getLastDisplayedElement(
    selector: string,
    timeout = BasePage.DEFAULT_TIMEOUT,
  ): Promise<ChainableElement> {
    // Wait for at least one element to exist
    await browser.$(selector).waitForExist({timeout});

    const elements = browser.$$(selector);
    const count = await elements.length;

    // Find the last displayed element (typically the topmost in stacked UI)
    for (let i = count - 1; i >= 0; i--) {
      const element = elements[i];
      if (await element.isDisplayed()) {
        return element;
      }
    }

    // Fallback to last element if none are displayed (shouldn't happen)
    return elements[count - 1];
  }
}
