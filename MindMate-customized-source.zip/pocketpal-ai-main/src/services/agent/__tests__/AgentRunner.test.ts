import {abortableFetch} from '../../../../jest/abortableFetch';

import {runAgent} from '../AgentRunner';
import type {AgentEvent} from '../AgentRunner.types';
import type {
  ApiCompletionParams,
  CompletionEngine,
  CompletionResult,
  CompletionStreamData,
} from '../../../utils/completionTypes';
import type {
  TalentEngine,
  TalentExecuteContext,
  TalentResult,
} from '../../talents/types';
import type {SearchAccess} from '../../talents/searchAccess';
import {WebSearchEngine} from '../../talents/WebSearchEngine';
import {ReadUrlEngine} from '../../talents/ReadUrlEngine';
import {
  allowReadUrls,
  matchReadUrl,
  resetReadUrlAllowlist,
} from '../../talents/readUrlAllowlist';
import {TavilyProvider} from '../../search/providers/tavily';
import {
  getCachedHits,
  resetSearchCache,
  setCachedHits,
} from '../../search/searchBudget';
import type {SearchProvider} from '../../search/types';

/**
 * Helper: build a CompletionEngine whose `completion()` invokes the
 * callback with each scripted token, then resolves with the supplied
 * `result`. Mirrors how llama.rn streams real tokens via JS callbacks.
 */
function makeScriptedEngine(opts: {
  scripts: Array<{
    tokens: CompletionStreamData[];
    result: CompletionResult;
  }>;
}): CompletionEngine {
  let turnIndex = 0;
  return {
    completion: jest.fn(
      async (
        _params: ApiCompletionParams,
        cb?: (d: CompletionStreamData) => void,
      ): Promise<CompletionResult> => {
        const turn = opts.scripts[turnIndex] ?? {
          tokens: [],
          result: {text: '', content: ''} as CompletionResult,
        };
        turnIndex += 1;
        if (cb) {
          for (const t of turn.tokens) {
            cb(t);
          }
        }
        return turn.result;
      },
    ),
    stopCompletion: jest.fn(async () => {}),
  };
}

function makeTalent(
  name: string,
  impl: (args: Record<string, any>) => Promise<TalentResult> | TalentResult,
): TalentEngine {
  return {
    name,
    execute: async args => Promise.resolve(impl(args)),
    toToolDefinition: () => ({
      type: 'function',
      function: {name, description: name, parameters: {}},
    }),
  };
}

const baseParams: ApiCompletionParams = {messages: []} as any;

function eventLabel(e: AgentEvent): string {
  if (e.type === 'tool_call_started') {
    return `${e.type} ${e.call.id}`;
  }
  if (e.type === 'tool_call_finished') {
    return `${e.type} ${e.outcome.callId}`;
  }
  return e.type;
}

async function collect(iter: AsyncIterable<AgentEvent>): Promise<AgentEvent[]> {
  const out: AgentEvent[] = [];
  for await (const e of iter) {
    out.push(e);
  }
  return out;
}

describe('runAgent', () => {
  // ---------- Story Test Requirements (AgentRunner) #1–#18 ----------

  it('#1 single turn, no tools → run_started, step_started, token*, step_finished, run_finished', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'hi'}, {content: ' there'}],
          result: {text: 'hi there', content: 'hi there'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const types = events.map(e => e.type);
    expect(types).toEqual([
      'run_started',
      'step_started',
      'token',
      'token',
      'step_finished',
      'run_finished',
    ]);
    const finished = events[events.length - 1] as Extract<
      AgentEvent,
      {type: 'run_finished'}
    >;
    expect(finished.result.hitMaxTurns).toBe(false);
  });

  it('#2 one tool call → loops once, two step_started events', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'Let me calculate'}],
          result: {
            text: 'Let me calculate',
            content: 'Let me calculate',
            tool_calls: [
              {
                id: 'call-0',
                type: 'function',
                function: {name: 'calculate', arguments: '{"expr":"2+2"}'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'The answer is 4'}],
          result: {text: 'The answer is 4', content: 'The answer is 4'},
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '4',
    }));

    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: name => (name === 'calculate' ? calculate : undefined),
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const stepStarts = events.filter(e => e.type === 'step_started');
    expect(stepStarts).toHaveLength(2);
    expect((stepStarts[0] as any).isFollowUp).toBe(false);
    expect((stepStarts[1] as any).isFollowUp).toBe(true);
    const finished = events.filter(e => e.type === 'tool_call_finished');
    expect(finished).toHaveLength(1);
    expect((finished[0] as any).outcome.responseContent).toBe('4');
  });

  it('#3 tool call but second turn yields no further tool_calls → run finishes after follow-up', async () => {
    // Note: the runner does not consult `requiresModelResponse`; it always
    // performs a follow-up turn after tool calls and only exits the loop
    // when the next turn yields no tool_calls. Story Test #3 in the
    // current runner shape is therefore identical to #2 from a control
    // flow perspective. This test asserts the early termination path.
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'render_html', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'all done', content: 'all done'},
        },
      ],
    });
    const renderHtml = makeTalent('render_html', () => ({
      type: 'html',
      html: '<p>hi</p>',
      summary: 'rendered',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['render_html'],
        talentLookup: () => renderHtml,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const finished = events[events.length - 1];
    expect(finished.type).toBe('run_finished');
    expect(
      events.find(
        e =>
          e.type === 'tool_call_finished' &&
          e.outcome.toolName === 'render_html',
      ),
    ).toBeTruthy();
  });

  it('#4 chained tool calls → multi-turn loop', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c1',
                type: 'function',
                function: {name: 'calculate', arguments: '{"expr":"1+1"}'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'final'}],
          result: {text: 'final', content: 'final'},
        },
      ],
    });
    const datetime = makeTalent('datetime', () => ({
      type: 'text',
      summary: 'now',
    }));
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '2',
    }));

    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['datetime', 'calculate'],
        talentLookup: name =>
          name === 'datetime'
            ? datetime
            : name === 'calculate'
              ? calculate
              : undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    expect(events.filter(e => e.type === 'step_started')).toHaveLength(3);
    expect(events.filter(e => e.type === 'tool_call_finished')).toHaveLength(2);
    expect(events[events.length - 1].type).toBe('run_finished');
  });

  it('#5 maxTurns hit → run_finished with hitMaxTurns=true (NOT run_failed)', async () => {
    // Engine always asks for more tools — never produces a final answer.
    const engine: CompletionEngine = {
      completion: jest.fn(async (_p, cb) => {
        cb?.({});
        return {
          text: '',
          content: '',
          tool_calls: [
            {
              id: `c-${Math.random()}`,
              type: 'function',
              function: {name: 'datetime', arguments: '{}'},
            },
          ],
        } as CompletionResult;
      }),
      stopCompletion: jest.fn(async () => {}),
    };
    const datetime = makeTalent('datetime', () => ({
      type: 'text',
      summary: 'now',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['datetime'],
        talentLookup: () => datetime,
        messageId: 'msg',
        triggerMarkers: [],
        maxTurns: 3,
      }),
    );
    const finished = events.find(e => e.type === 'run_finished') as
      | Extract<AgentEvent, {type: 'run_finished'}>
      | undefined;
    expect(finished).toBeDefined();
    expect(finished!.result.hitMaxTurns).toBe(true);
    expect(events.find(e => e.type === 'run_failed')).toBeUndefined();
  });

  it('#5b turn cap with pending tool requests → one forced no-tools completion produces the final answer', async () => {
    const seenParams: ApiCompletionParams[] = [];
    // Tool-calls whenever tools are offered; a text answer once they are not.
    const engine: CompletionEngine = {
      completion: jest.fn(async (p: ApiCompletionParams, cb) => {
        seenParams.push(p);
        if (p.tools) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: `c-${seenParams.length}`,
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          } as CompletionResult;
        }
        cb?.({content: 'Answer from gathered results.'});
        return {
          text: 'Answer from gathered results.',
          content: 'Answer from gathered results.',
        } as CompletionResult;
      }),
      stopCompletion: jest.fn(async () => {}),
    };
    const datetime = makeTalent('datetime', () => ({
      type: 'text',
      summary: 'now',
    }));

    const events = await collect(
      runAgent({
        engine,
        initialParams: {messages: [], tools: [{}]} as any,
        allowedTalentNames: ['datetime'],
        talentLookup: () => datetime,
        messageId: 'msg',
        triggerMarkers: [],
        maxTurns: 2,
      }),
    );

    // 2 budgeted turns + exactly one forced closing completion.
    expect(engine.completion).toHaveBeenCalledTimes(3);
    const forcedParams = seenParams[2];
    expect(forcedParams.tools).toBeUndefined();
    const forcedMessages = (forcedParams.messages ?? []) as any[];
    const lastMessage = forcedMessages[forcedMessages.length - 1];
    expect(lastMessage.role).toBe('user');
    expect(lastMessage.content).toContain('Tool budget exhausted');

    // The forced turn streams and finishes like a normal final turn.
    const stepStarts = events.filter(e => e.type === 'step_started');
    expect(stepStarts).toHaveLength(3);
    expect((stepStarts[2] as any).isFollowUp).toBe(true);
    const finalToken = events.find(
      e =>
        e.type === 'token' &&
        (e as any).delta.content === 'Answer from gathered results.',
    );
    expect(finalToken).toBeDefined();
    const stepFinishes = events.filter(e => e.type === 'step_finished');
    expect((stepFinishes[2] as any).toolCalls).toBeUndefined();

    const finished = events[events.length - 1] as Extract<
      AgentEvent,
      {type: 'run_finished'}
    >;
    expect(finished.type).toBe('run_finished');
    expect(finished.result.hitMaxTurns).toBe(true);
    expect(finished.result.finalResult.content).toBe(
      'Answer from gathered results.',
    );
  });

  it('#5c no forced completion when the model answers within the turn budget', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'direct answer'}],
          result: {text: 'direct answer', content: 'direct answer'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: {messages: [], tools: [{}]} as any,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
        maxTurns: 2,
      }),
    );
    expect(engine.completion).toHaveBeenCalledTimes(1);
    const finished = events[events.length - 1] as Extract<
      AgentEvent,
      {type: 'run_finished'}
    >;
    expect(finished.result.hitMaxTurns).toBe(false);
  });

  it('#6 malformed JSON args → tool_call_finished with error outcome', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{not json'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'sorry'}],
          result: {text: 'sorry', content: 'sorry'},
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: 'ignored',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () => calculate,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tcf = events.find(e => e.type === 'tool_call_finished') as Extract<
      AgentEvent,
      {type: 'tool_call_finished'}
    >;
    expect(tcf).toBeDefined();
    expect(tcf.outcome.result.type).toBe('error');
    expect(tcf.outcome.responseContent).toMatch(/invalid JSON/);
  });

  it('#7 unknown talent (not in registry) → outcome.result.type === error', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'mystery', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'ok', content: 'ok'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        // Talent IS in allowedTalentNames but NOT in the registry.
        allowedTalentNames: ['mystery'],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tcf = events.find(e => e.type === 'tool_call_finished') as Extract<
      AgentEvent,
      {type: 'tool_call_finished'}
    >;
    expect(tcf.outcome.result.type).toBe('error');
    expect(tcf.outcome.responseContent).toMatch(/not available/);
  });

  it('#8 talent not in allowedTalentNames → outcome rejected', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'evil', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'ok', content: 'ok'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        // Empty allow-list — model invented a tool the Pal does not advertise.
        allowedTalentNames: [],
        talentLookup: () =>
          makeTalent('evil', () => ({type: 'text', summary: 'pwn'})),
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tcf = events.find(e => e.type === 'tool_call_finished') as Extract<
      AgentEvent,
      {type: 'tool_call_finished'}
    >;
    expect(tcf.outcome.result.type).toBe('error');
    expect(tcf.outcome.responseContent).toMatch(/not enabled/);
  });

  it('#9 talent execute() throws → outcome.result.type === error', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'broken', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'ok', content: 'ok'},
        },
      ],
    });
    const broken: TalentEngine = {
      name: 'broken',
      execute: async () => {
        throw new Error('kaboom');
      },
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'broken', description: '', parameters: {}},
      }),
    };
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['broken'],
        talentLookup: () => broken,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tcf = events.find(e => e.type === 'tool_call_finished') as Extract<
      AgentEvent,
      {type: 'tool_call_finished'}
    >;
    expect(tcf.outcome.result.type).toBe('error');
    expect(tcf.outcome.responseContent).toMatch(/kaboom/);
  });

  it('#10 signal.aborted=true between turns → run terminates without follow-up', async () => {
    const controller = new AbortController();
    const engine: CompletionEngine = {
      completion: jest.fn(async (_p, cb) => {
        cb?.({content: 'first'});
        // Abort once the first turn finishes — i.e. before the next loop iteration.
        controller.abort();
        return {
          text: 'first',
          content: 'first',
          tool_calls: [
            {
              id: 'c0',
              type: 'function',
              function: {name: 'datetime', arguments: '{}'},
            },
          ],
        } as CompletionResult;
      }),
      stopCompletion: jest.fn(async () => {}),
    };
    const datetime = makeTalent('datetime', () => ({
      type: 'text',
      summary: 'now',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['datetime'],
        talentLookup: () => datetime,
        messageId: 'msg',
        triggerMarkers: [],
        signal: controller.signal,
      }),
    );
    const stepStarts = events.filter(e => e.type === 'step_started');
    // No follow-up step_started after the abort.
    expect(stepStarts).toHaveLength(1);
    expect(events[events.length - 1].type).toBe('run_finished');
  });

  it('#11 triggerMarkers contains marker, content matches → marker_seen fires exactly once', async () => {
    // The model streams a marker but never produces a parsed tool_call —
    // the runner must still emit marker_seen so the UI can flip its
    // status copy at marker time.
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'preamble <tool_call> trailing'}],
          result: {
            text: 'preamble <tool_call> trailing',
            content: 'preamble <tool_call> trailing',
          },
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: ['<tool_call>'],
      }),
    );
    const markerSeen = events.filter(e => e.type === 'marker_seen');
    expect(markerSeen).toHaveLength(1);
    expect((markerSeen[0] as any).marker).toBe('<tool_call>');
  });

  it('#19 marker straddles two stream chunks → token,token,marker_seen in order', async () => {
    // Chunk 1 ends with a partial marker prefix; chunk 2 completes it.
    // The runner must enqueue the token event for each chunk in order
    // and only emit marker_seen AFTER the second token (the one whose
    // content completed the substring).
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'foo<tool_'}, {content: 'call>bar'}],
          result: {
            text: 'foo<tool_call>bar',
            content: 'foo<tool_call>bar',
          },
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: ['<tool_call>'],
      }),
    );

    // Filter to only the in-step events (drop run_started/step_started/
    // step_finished/run_finished framing) so the explicit ordering
    // assertion focuses on the streaming bridge's emission sequence.
    const streamEvents = events.filter(
      e => e.type === 'token' || e.type === 'marker_seen',
    );
    expect(streamEvents).toHaveLength(3);
    expect(streamEvents[0].type).toBe('token');
    expect((streamEvents[0] as any).delta.content).toBe('foo<tool_');
    expect(streamEvents[1].type).toBe('token');
    expect((streamEvents[1] as any).delta.content).toBe('call>bar');
    expect(streamEvents[2].type).toBe('marker_seen');
    expect((streamEvents[2] as any).marker).toBe('<tool_call>');

    // Exactly one marker_seen for the whole step.
    expect(events.filter(e => e.type === 'marker_seen')).toHaveLength(1);
  });

  it('#20 triggerMarkers: [] → no marker_seen events; tool flow still correct via tool_call_started', async () => {
    // Empty triggerMarkers disables marker scanning entirely. The
    // runner must skip the scan and still emit tool_call_started/
    // tool_call_finished as normal when the engine returns parsed
    // tool_calls.
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'preamble <tool_call> trailing'}],
          result: {
            text: 'preamble <tool_call> trailing',
            content: 'preamble <tool_call> trailing',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{"expr":"1+1"}'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'final'}],
          result: {text: 'final', content: 'final'},
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '2',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () => calculate,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    expect(events.filter(e => e.type === 'marker_seen')).toHaveLength(0);
    // tool_call_started fired (the UX path that drives status flip in
    // the absence of marker scanning).
    expect(events.filter(e => e.type === 'tool_call_started')).toHaveLength(1);
    expect(events.filter(e => e.type === 'tool_call_finished')).toHaveLength(1);
  });

  it('#21 multi-step run with markers in step 0 and step 1 → exactly two marker_seen, each after its step token', async () => {
    // Step 0: model emits marker, parsed tool_calls arrive →
    // tool executes, follow-up step starts.
    // Step 1: model emits marker again in the follow-up content.
    // Per-step reset semantics: each iteration declares a fresh
    // markerSeenThisStep flag, so both steps independently fire
    // marker_seen exactly once.
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'thinking <tool_call> calling'}],
          result: {
            text: 'thinking <tool_call> calling',
            content: 'thinking <tool_call> calling',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{"expr":"1+1"}'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'follow-up <tool_call> again'}],
          result: {
            text: 'follow-up <tool_call> again',
            content: 'follow-up <tool_call> again',
          },
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '2',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () => calculate,
        messageId: 'msg',
        triggerMarkers: ['<tool_call>'],
      }),
    );
    const markerSeen = events.filter(e => e.type === 'marker_seen');
    expect(markerSeen).toHaveLength(2);

    // Verify each marker_seen comes AFTER a token within its own
    // step_started/step_finished window. We slice the event sequence
    // by step boundaries and check the ordering inside each.
    const stepStartedIdx = events
      .map((e, i) => ({e, i}))
      .filter(({e}) => e.type === 'step_started')
      .map(({i}) => i);
    const stepFinishedIdx = events
      .map((e, i) => ({e, i}))
      .filter(({e}) => e.type === 'step_finished')
      .map(({i}) => i);
    expect(stepStartedIdx).toHaveLength(2);
    expect(stepFinishedIdx).toHaveLength(2);

    for (let s = 0; s < 2; s += 1) {
      const slice = events.slice(stepStartedIdx[s], stepFinishedIdx[s] + 1);
      const tokens = slice.filter(e => e.type === 'token');
      const markers = slice.filter(e => e.type === 'marker_seen');
      expect(markers).toHaveLength(1);
      expect(tokens.length).toBeGreaterThanOrEqual(1);
      const tokenIdx = slice.findIndex(e => e.type === 'token');
      const markerIdx = slice.findIndex(e => e.type === 'marker_seen');
      expect(tokenIdx).toBeLessThan(markerIdx);
    }
  });

  it('#13 tool_calls with id=null → outcomes carry deterministic synthetic ids', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: null as any,
                type: 'function',
                function: {name: 'calculate', arguments: '{}'},
              },
              {
                id: '' as any,
                type: 'function',
                function: {name: 'calculate', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'ok', content: 'ok'},
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '0',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () => calculate,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const finished = events.filter(e => e.type === 'tool_call_finished');
    expect(finished).toHaveLength(2);
    const ids = finished.map(e => (e as any).outcome.callId as string);
    expect(ids[0]).toMatch(/^call_/);
    expect(ids[1]).toMatch(/^call_/);
    expect(ids[0]).not.toBe(ids[1]);
  });

  it('#14 engine rejects → run_failed emitted, iterator ends', async () => {
    const engine: CompletionEngine = {
      completion: jest.fn(async () => {
        throw new Error('engine boom');
      }),
      stopCompletion: jest.fn(async () => {}),
    };
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const last = events[events.length - 1];
    expect(last.type).toBe('run_failed');
    expect((last as any).error.message).toBe('engine boom');
  });

  it('#15 module graph contains no react/mobx/mobx-react-lite/store imports', () => {
    // Walk the runner module's transitive require tree (module.children).
    // This is more precise than scanning require.cache, which is global
    // (mobx etc. may already be loaded by jest/setup.ts before this test
    // runs). We only care about what the runner ITSELF reaches.
    const runnerPath = require.resolve('../AgentRunner');
    const runnerMod: NodeModule | undefined = require.cache[runnerPath];
    if (!runnerMod) {
      // Force-load the runner if it isn't already cached.
      require('../AgentRunner');
    }
    const startMod: NodeModule = require.cache[runnerPath]!;
    expect(startMod).toBeDefined();

    const visited = new Set<string>();
    const queue: NodeModule[] = [startMod];
    while (queue.length > 0) {
      const m = queue.shift()!;
      if (visited.has(m.id)) {
        continue;
      }
      visited.add(m.id);
      for (const child of m.children) {
        queue.push(child);
      }
    }

    const forbidden = [
      /[\\/]node_modules[\\/]react[\\/]/,
      /[\\/]node_modules[\\/]mobx[\\/]/,
      /[\\/]node_modules[\\/]mobx-react-lite[\\/]/,
      /[\\/]node_modules[\\/]react-native[\\/]/,
      /[\\/]src[\\/]store[\\/]/,
      // The runner must NOT import the trigger-marker cache module —
      // it consumes `triggerMarkers` only as a `string[]` value
      // injected through `AgentRunOptions`. Locks the architectural
      // invariant in CI rather than relying on a one-time grep.
      /[\\/]services[\\/]agent[\\/]triggerMarkers/,
    ];
    const reachable = Array.from(visited);
    for (const re of forbidden) {
      const hit = reachable.find(p => re.test(p));
      expect(hit).toBeUndefined();
    }
  });

  it('#16 stop mid-tool: signal.aborted during executeOne() → in-flight outcome appended, then run_finished', async () => {
    const controller = new AbortController();
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'slow', arguments: '{}'},
              },
            ],
          },
        },
        // No second turn expected — abort fires at the boundary after tool execution.
      ],
    });
    const slow: TalentEngine = {
      name: 'slow',
      // The talent's execute() runs to completion; abort fires DURING it,
      // but the runner does not cancel synchronous-ish talents — the
      // outcome is still appended.
      execute: async () => {
        controller.abort();
        return {type: 'text', summary: 'late'};
      },
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'slow', description: '', parameters: {}},
      }),
    };
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['slow'],
        talentLookup: () => slow,
        messageId: 'msg',
        triggerMarkers: [],
        signal: controller.signal,
      }),
    );
    const tcf = events.find(e => e.type === 'tool_call_finished');
    expect(tcf).toBeDefined();
    expect((tcf as any).outcome.responseContent).toBe('late');
    expect(events[events.length - 1].type).toBe('run_finished');
    // No second step_started (abort caught at the turn boundary).
    expect(events.filter(e => e.type === 'step_started')).toHaveLength(1);
    expect(engine.stopCompletion).not.toHaveBeenCalled();
  });

  it('#17 backpressure: many tokens emitted before consumer pulls → all events delivered in order', async () => {
    const tokens: CompletionStreamData[] = [];
    for (let i = 0; i < 100; i += 1) {
      tokens.push({content: String(i)});
    }
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens,
          result: {text: '', content: ''} as CompletionResult,
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tokenEvents = events.filter(e => e.type === 'token');
    expect(tokenEvents).toHaveLength(100);
    const seq = tokenEvents.map(e => (e as any).delta.content);
    for (let i = 0; i < 100; i += 1) {
      expect(seq[i]).toBe(String(i));
    }
  });

  it('#18 backpressure: consumer slower than producer → no event drop, no deadlock', async () => {
    const N = 50;
    const tokens: CompletionStreamData[] = Array.from({length: N}, (_, i) => ({
      content: `t${i}`,
    }));
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens,
          result: {text: '', content: ''} as CompletionResult,
        },
      ],
    });
    const out: AgentEvent[] = [];
    for await (const e of runAgent({
      engine,
      initialParams: baseParams,
      allowedTalentNames: [],
      talentLookup: () => undefined,
      messageId: 'msg',
      triggerMarkers: [],
    })) {
      out.push(e);
      // Slow the consumer — let other microtasks run between pulls.
      await new Promise(r => setTimeout(r, 0));
    }
    const tokenEvents = out.filter(e => e.type === 'token');
    expect(tokenEvents).toHaveLength(N);
    for (let i = 0; i < N; i += 1) {
      expect((tokenEvents[i] as any).delta.content).toBe(`t${i}`);
    }
    expect(out[out.length - 1].type).toBe('run_finished');
  });

  // ---------- Additional coverage ----------

  it('reasoning_content per token is forwarded as TokenDelta.reasoningContent', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{reasoning_content: 'thinking…'}, {content: 'final'}],
          result: {
            text: 'final',
            content: 'final',
            reasoning_content: 'thinking…',
          },
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    const tokens = events.filter(e => e.type === 'token');
    expect((tokens[0] as any).delta.reasoningContent).toBe('thinking…');
    expect((tokens[1] as any).delta.content).toBe('final');
  });

  it('yields every tool_call_started of a batch, then every tool_call_finished, in call order', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{}'},
              },
              {
                id: 'c1',
                type: 'function',
                function: {name: 'calculate', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [],
          result: {text: 'done', content: 'done'},
        },
      ],
    });
    const calculate = makeTalent('calculate', () => ({
      type: 'text',
      summary: '0',
    }));
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () => calculate,
        messageId: 'msg',
        triggerMarkers: [],
      }),
    );
    expect(events.map(eventLabel)).toEqual([
      'run_started',
      'step_started',
      'step_finished',
      'tool_call_started c0',
      'tool_call_started c1',
      'tool_call_finished c0',
      'tool_call_finished c1',
      'step_started',
      'step_finished',
      'run_finished',
    ]);
  });

  // ---------- Tool-call-progress signal source ----------
  //
  // PendingIndicator surfaces a live char/line count during
  // `generating_tool_call`, sourced from
  // `delta.toolCalls[0].function.arguments`. That only works if the
  // engine emits incremental tool_calls deltas mid-stream. This test
  // proves OUR pipeline works in that case — if the indicator stays
  // empty on device, the problem is upstream (the engine isn't
  // streaming tool_calls; on-device verification via the
  // [pending-debug] logs).
  it('progressive tool_calls deltas reach the iterator with growing args', async () => {
    const stages = [
      '{"html":"<!doc',
      '{"html":"<!doctype html>\\n<html>',
      '{"html":"<!doctype html>\\n<html>\\n<body>"',
    ];
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: stages.map(args => ({
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'render_html', arguments: args},
              },
            ],
          })),
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {
                  name: 'render_html',
                  arguments: stages[stages.length - 1],
                },
              },
            ],
          },
        },
        {
          tokens: [{content: 'done'}],
          result: {text: 'done', content: 'done'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['render_html'],
        talentLookup: () =>
          makeTalent('render_html', () => ({
            type: 'html',
            html: 'x',
            summary: 's',
          })),
        triggerMarkers: [],
        messageId: 'm',
      }),
    );
    // Each scripted token chunk produced a `token` event whose
    // delta.toolCalls[0].function.arguments matches the staged length.
    const tokenEvents = events.filter(
      (e): e is Extract<AgentEvent, {type: 'token'}> => e.type === 'token',
    );
    const argLens = tokenEvents
      .map(e => {
        const a = e.delta.toolCalls?.[0]?.function?.arguments;
        return typeof a === 'string' ? a.length : -1;
      })
      .filter(n => n >= 0);
    expect(argLens).toEqual(stages.map(s => s.length));
    // Strictly increasing — the count source for the indicator.
    for (let i = 1; i < argLens.length; i++) {
      expect(argLens[i]).toBeGreaterThan(argLens[i - 1]);
    }
  });

  // ---------- Per-call metrics (post-hoc tokens + duration) ----------
  //
  // The runner counts streaming `token` events that carry tool_calls
  // and tracks the wall-clock duration from the first such event to
  // step finalisation. The metrics ride on the normalized toolCalls
  // attached to `step_finished`, which the hook persists via
  // appendToolCall — so post-hoc UI (chip + preview footer) can show
  // them without any new persistence path.
  it('attaches per-call generation metrics on step_finished', async () => {
    const stages = ['{"a":', '{"a":1', '{"a":12', '{"a":123}'];
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: stages.map(args => ({
            tool_calls: [
              {
                id: 'c0',
                type: 'function' as const,
                function: {name: 'calculate', arguments: args},
              },
            ],
          })),
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {
                  name: 'calculate',
                  arguments: stages[stages.length - 1],
                },
              },
            ],
          },
        },
        {
          tokens: [{content: 'done'}],
          result: {text: 'done', content: 'done'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate'],
        talentLookup: () =>
          makeTalent('calculate', () => ({type: 'text', summary: '0'})),
        triggerMarkers: [],
        messageId: 'm',
      }),
    );
    const stepFinished = events.find(
      (e): e is Extract<AgentEvent, {type: 'step_finished'}> =>
        e.type === 'step_finished' && !!e.toolCalls && e.toolCalls.length > 0,
    );
    expect(stepFinished).toBeDefined();
    const call = stepFinished!.toolCalls![0];
    expect(call.metrics).toBeDefined();
    expect(call.metrics!.tokens).toBe(stages.length);
    // Duration is wall-clock — assert it's a non-negative finite number
    // rather than a precise value (test scheduling is non-deterministic).
    expect(call.metrics!.durationMs).toBeGreaterThanOrEqual(0);
    expect(Number.isFinite(call.metrics!.durationMs)).toBe(true);
  });

  it('multi-tool steps replicate the step total onto each call', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [
            {
              tool_calls: [
                {
                  id: 'c0',
                  type: 'function',
                  function: {name: 'calculate', arguments: '{}'},
                },
                {
                  id: 'c1',
                  type: 'function',
                  function: {name: 'datetime', arguments: '{}'},
                },
              ],
            },
            {
              tool_calls: [
                {
                  id: 'c0',
                  type: 'function',
                  function: {name: 'calculate', arguments: '{"x":1}'},
                },
                {
                  id: 'c1',
                  type: 'function',
                  function: {name: 'datetime', arguments: '{}'},
                },
              ],
            },
          ],
          result: {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{"x":1}'},
              },
              {
                id: 'c1',
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          },
        },
        {
          tokens: [{content: 'done'}],
          result: {text: 'done', content: 'done'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: ['calculate', 'datetime'],
        talentLookup: name =>
          makeTalent(name, () => ({type: 'text', summary: '0'})),
        triggerMarkers: [],
        messageId: 'm',
      }),
    );
    const stepFinished = events.find(
      (e): e is Extract<AgentEvent, {type: 'step_finished'}> =>
        e.type === 'step_finished' && !!e.toolCalls && e.toolCalls.length > 0,
    );
    expect(stepFinished).toBeDefined();
    const calls = stepFinished!.toolCalls!;
    expect(calls).toHaveLength(2);
    expect(calls[0].metrics?.tokens).toBe(2);
    expect(calls[1].metrics?.tokens).toBe(2);
  });

  it('omits metrics on text-only steps (no tool-call tokens seen)', async () => {
    const engine = makeScriptedEngine({
      scripts: [
        {
          tokens: [{content: 'hi there'}],
          result: {text: 'hi there', content: 'hi there'},
        },
      ],
    });
    const events = await collect(
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        triggerMarkers: [],
        messageId: 'm',
      }),
    );
    const stepFinished = events.find(
      (e): e is Extract<AgentEvent, {type: 'step_finished'}> =>
        e.type === 'step_finished',
    );
    expect(stepFinished).toBeDefined();
    expect(stepFinished!.toolCalls).toBeUndefined();
  });

  describe('abort contract', () => {
    function pendingEngine() {
      let finish!: (result: CompletionResult) => void;
      const engine: CompletionEngine = {
        completion: jest.fn(
          () =>
            new Promise<CompletionResult>(resolve => {
              finish = resolve;
            }),
        ),
        stopCompletion: jest.fn(async () => {}),
      };
      return {engine, finish: (r: CompletionResult) => finish(r)};
    }

    const flush = async () => {
      for (let i = 0; i < 10; i += 1) {
        await Promise.resolve();
      }
    };

    afterEach(() => {
      jest.useRealTimers();
    });

    it('abort while step_started is handled → step_finished with no calls, no completion', async () => {
      const controller = new AbortController();
      const engine = makeScriptedEngine({scripts: []});
      const events: AgentEvent[] = [];
      for await (const e of runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
        signal: controller.signal,
      })) {
        events.push(e);
        if (e.type === 'step_started') {
          controller.abort();
        }
      }

      expect(engine.completion).not.toHaveBeenCalled();
      expect(events.map(e => e.type)).toEqual([
        'run_started',
        'step_started',
        'step_finished',
        'run_finished',
      ]);
      expect((events[2] as any).toolCalls).toBeUndefined();
    });

    it('a signal aborted before the run → one empty step, no completion', async () => {
      const controller = new AbortController();
      controller.abort();
      const engine = makeScriptedEngine({scripts: []});
      const events = await collect(runWith(engine, controller.signal));

      expect(engine.completion).not.toHaveBeenCalled();
      expect(engine.stopCompletion).not.toHaveBeenCalled();
      expect(events.map(e => e.type)).toEqual([
        'run_started',
        'step_started',
        'step_finished',
        'run_finished',
      ]);
    });

    function runWith(engine: CompletionEngine, signal?: AbortSignal) {
      return runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: [],
        talentLookup: () => undefined,
        messageId: 'msg',
        triggerMarkers: [],
        signal,
      });
    }

    function streamingPendingEngine() {
      const {engine} = pendingEngine();
      let finish!: (result: CompletionResult) => void;
      (engine.completion as jest.Mock).mockImplementation(
        (_p: ApiCompletionParams, cb?: (d: CompletionStreamData) => void) =>
          new Promise<CompletionResult>(resolve => {
            cb?.({content: 'partial'});
            finish = resolve;
          }),
      );
      return {
        engine,
        finish: () =>
          finish({text: 'partial', content: 'partial'} as CompletionResult),
      };
    }

    async function nextToken(iterator: AsyncGenerator<AgentEvent>) {
      let event = await iterator.next();
      while (!event.done && event.value.type !== 'token') {
        event = await iterator.next();
      }
    }

    it('sends one stopCompletion per abort while a completion is unsettled', async () => {
      jest.useFakeTimers();
      const controller = new AbortController();
      const {engine, finish} = pendingEngine();
      const run = collect(runWith(engine, controller.signal));
      await flush();
      expect(engine.completion).toHaveBeenCalledTimes(1);

      controller.abort();
      jest.advanceTimersByTime(1000);
      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);

      finish({text: '', content: ''} as CompletionResult);
      const events = await run;

      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
      expect(engine.completion).toHaveBeenCalledTimes(1);
      expect(events[events.length - 1].type).toBe('run_finished');
    });

    it('a consumer that stops iterating mid-completion stops it once and waits for it to settle', async () => {
      const {engine, finish} = streamingPendingEngine();
      const iterator = runWith(engine);
      await nextToken(iterator);

      let returned = false;
      const returning = iterator.return(undefined).then(() => {
        returned = true;
      });
      await flush();

      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
      expect(returned).toBe(false);

      finish();
      await returning;
      expect(returned).toBe(true);
      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
    });

    it('an abort followed by return() stops once', async () => {
      const controller = new AbortController();
      const {engine, finish} = streamingPendingEngine();
      const iterator = runWith(engine, controller.signal);
      await nextToken(iterator);

      controller.abort();
      const returning = iterator.return(undefined);
      await flush();
      finish();
      await returning;

      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
    });

    it('an abort while return() awaits the completion stops once', async () => {
      const controller = new AbortController();
      const {engine, finish} = streamingPendingEngine();
      const iterator = runWith(engine, controller.signal);
      await nextToken(iterator);

      const returning = iterator.return(undefined);
      await flush();
      controller.abort();
      await flush();
      finish();
      await returning;

      expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
    });

    it.each([
      [
        'throws synchronously',
        () => {
          throw new Error('Context not found');
        },
      ],
      ['returns undefined', () => undefined],
    ])(
      'an abort whose stopCompletion %s neither throws nor keeps the run alive',
      async (_label, stop) => {
        const warn = jest.spyOn(console, 'warn').mockImplementation(() => {});
        const controller = new AbortController();
        const {engine, finish} = pendingEngine();
        (engine.stopCompletion as jest.Mock).mockImplementation(stop);
        const run = collect(runWith(engine, controller.signal));
        await flush();

        expect(() => controller.abort()).not.toThrow();
        finish({text: '', content: ''} as CompletionResult);
        const events = await run;

        expect(engine.stopCompletion).toHaveBeenCalledTimes(1);
        expect(events[events.length - 1].type).toBe('run_finished');
        warn.mockRestore();
      },
    );
  });

  describe('run signal reaches the talent', () => {
    const oneCall = (name: string) =>
      makeScriptedEngine({
        scripts: [
          {
            tokens: [],
            result: {
              text: '',
              content: '',
              tool_calls: [
                {id: 'c0', type: 'function', function: {name, arguments: '{}'}},
              ],
            },
          },
        ],
      });
    const spyTalent = () => {
      const execute = jest.fn<
        Promise<TalentResult>,
        Parameters<TalentEngine['execute']>
      >(async () => ({type: 'text', summary: 'ok'}));
      const talent: TalentEngine = {
        name: 'probe',
        execute,
        toToolDefinition: () => ({
          type: 'function',
          function: {name: 'probe', description: '', parameters: {}},
        }),
      };
      return {talent, execute};
    };

    it('passes every call one tool signal that aborts with the run signal', async () => {
      const controller = new AbortController();
      const signals: AbortSignal[] = [];
      const releases: Array<() => void> = [];
      const talent: TalentEngine = {
        name: 'probe',
        execute: (_args, ctx) =>
          new Promise<TalentResult>(resolve => {
            signals.push(ctx!.signal);
            releases.push(() => resolve({type: 'text', summary: 'ok'}));
          }),
        toToolDefinition: () => ({
          type: 'function',
          function: {name: 'probe', description: '', parameters: {}},
        }),
      };
      const probe = (id: string) => ({
        id,
        type: 'function' as const,
        function: {name: 'probe', arguments: '{}'},
      });
      const done = collect(
        runAgent({
          engine: makeScriptedEngine({
            scripts: [
              {
                tokens: [],
                result: {
                  text: '',
                  content: '',
                  tool_calls: [probe('c0'), probe('c1')],
                },
              },
            ],
          }),
          initialParams: baseParams,
          allowedTalentNames: ['probe'],
          talentLookup: () => talent,
          messageId: 'msg',
          triggerMarkers: [],
          signal: controller.signal,
        }),
      );
      for (let i = 0; i < 50 && signals.length < 2; i += 1) {
        await Promise.resolve();
      }

      expect(signals).toHaveLength(2);
      const [toolSignal, sibling] = signals;
      expect(sibling).toBe(toolSignal);
      expect(toolSignal).not.toBe(controller.signal);
      expect(toolSignal.aborted).toBe(false);

      controller.abort();
      expect(toolSignal.aborted).toBe(true);

      releases.forEach(release => release());
      await done;
    });

    it('calls execute with args only when the run has no signal', async () => {
      const {talent, execute} = spyTalent();
      await collect(
        runAgent({
          engine: oneCall('probe'),
          initialParams: baseParams,
          allowedTalentNames: ['probe'],
          talentLookup: () => talent,
          messageId: 'msg',
          triggerMarkers: [],
        }),
      );
      expect(execute.mock.calls[0]).toHaveLength(1);
    });

    it('continues to the follow-up turn when a search times out without Stop', async () => {
      jest.useFakeTimers();
      try {
        resetSearchCache();
        const controller = new AbortController();
        global.fetch = abortableFetch();
        const access: SearchAccess = {
          getActiveProvider: () => new TavilyProvider(() => 'key'),
          canSearch: () => true,
          getResultCount: () => 3,
          readWithDefaultReader: jest.fn(),
        };
        const engine = makeScriptedEngine({
          scripts: [
            {
              tokens: [],
              result: {
                text: '',
                content: '',
                tool_calls: [
                  {
                    id: 'c0',
                    type: 'function',
                    function: {
                      name: 'web_search',
                      arguments: JSON.stringify({query: 'mars'}),
                    },
                  },
                ],
              },
            },
            {tokens: [], result: {text: 'done', content: 'done'}},
          ],
        });

        const done = collect(
          runAgent({
            engine,
            initialParams: baseParams,
            allowedTalentNames: ['web_search'],
            talentLookup: () => new WebSearchEngine(access),
            messageId: 'msg',
            triggerMarkers: [],
            signal: controller.signal,
          }),
        );
        await jest.advanceTimersByTimeAsync(12000);
        const events = await done;

        const finished = events.find(e => e.type === 'tool_call_finished');
        expect((finished as any).outcome.result.errorMessage).toBe('timed out');
        expect(engine.completion).toHaveBeenCalledTimes(2);
        expect(controller.signal.aborted).toBe(false);
      } finally {
        jest.useRealTimers();
      }
    });

    it('cancels both searches of a batch when Stop lands during the first', async () => {
      resetSearchCache();
      const controller = new AbortController();
      global.fetch = abortableFetch({onCall: () => controller.abort()});
      const access: SearchAccess = {
        getActiveProvider: () => new TavilyProvider(() => 'key'),
        canSearch: () => true,
        getResultCount: () => 3,
        readWithDefaultReader: jest.fn(),
      };
      const webSearch = new WebSearchEngine(access);
      const search = (id: string, query: string) => ({
        id,
        type: 'function' as const,
        function: {name: 'web_search', arguments: JSON.stringify({query})},
      });
      const engine = makeScriptedEngine({
        scripts: [
          {
            tokens: [],
            result: {
              text: '',
              content: '',
              tool_calls: [search('c0', 'mars'), search('c1', 'venus')],
            },
          },
        ],
      });

      const events = await collect(
        runAgent({
          engine,
          initialParams: baseParams,
          allowedTalentNames: ['web_search'],
          talentLookup: () => webSearch,
          messageId: 'msg',
          triggerMarkers: [],
          signal: controller.signal,
        }),
      );

      const finished = events.filter(e => e.type === 'tool_call_finished');
      expect(finished.map(e => (e as any).outcome.result.errorMessage)).toEqual(
        ['cancelled', 'cancelled'],
      );
      expect(global.fetch).toHaveBeenCalledTimes(1);
      expect(
        events
          .map(e => e.type)
          .filter(t => t === 'tool_call_started' || t === 'tool_call_finished'),
      ).toEqual([
        'tool_call_started',
        'tool_call_started',
        'tool_call_finished',
        'tool_call_finished',
      ]);
      expect(events[events.length - 1].type).toBe('run_finished');
      expect(engine.completion).toHaveBeenCalledTimes(1);
    });
  });

  describe('concurrent dispatch', () => {
    const toolCall = (
      id: string,
      name: string,
      args: Record<string, unknown> = {},
    ) => ({
      id,
      type: 'function' as const,
      function: {name, arguments: JSON.stringify(args)},
    });
    const batchEngine = (calls: ReturnType<typeof toolCall>[]) =>
      makeScriptedEngine({
        scripts: [
          {tokens: [], result: {text: '', content: '', tool_calls: calls}},
          {tokens: [], result: {text: 'done', content: 'done'}},
        ],
      });
    const talentWith = (
      name: string,
      execute: TalentEngine['execute'],
    ): TalentEngine => ({
      name,
      execute,
      toToolDefinition: () => ({
        type: 'function',
        function: {name, description: name, parameters: {}},
      }),
    });
    const timedTalent = (name: string, ms: number, onSettle?: () => void) => {
      const execute = jest.fn(
        () =>
          new Promise<TalentResult>(resolve => {
            setTimeout(() => {
              onSettle?.();
              resolve({type: 'text', summary: name});
            }, ms);
          }),
      );
      return {talent: talentWith(name, execute), execute};
    };
    const deferredTalent = (name: string) => {
      let release!: () => void;
      const execute = jest.fn(
        (_args: Record<string, unknown>, _ctx?: TalentExecuteContext) =>
          new Promise<TalentResult>(resolve => {
            release = () => resolve({type: 'text', summary: name});
          }),
      );
      return {
        talent: talentWith(name, execute),
        execute,
        release: () => release(),
        signal: () => execute.mock.calls[0]?.[1]?.signal,
      };
    };
    const run = (
      engine: CompletionEngine,
      talents: Record<string, TalentEngine>,
      signal?: AbortSignal,
    ) =>
      runAgent({
        engine,
        initialParams: baseParams,
        allowedTalentNames: Object.keys(talents),
        talentLookup: name => talents[name],
        messageId: 'msg',
        triggerMarkers: [],
        signal,
      });
    const searchAccess = (provider: SearchProvider): SearchAccess => ({
      getActiveProvider: () => provider,
      canSearch: () => true,
      getResultCount: () => 3,
      readWithDefaultReader: jest.fn(async (url: string) => ({
        url,
        title: 'Mars',
        text: 'The red planet.',
      })),
    });
    const flush = async () => {
      for (let i = 0; i < 50; i += 1) {
        await Promise.resolve();
      }
    };
    const track = <T>(promise: Promise<T>) => {
      const state: {done: boolean; value?: T} = {done: false};
      promise.then(value => {
        state.done = true;
        state.value = value;
      });
      return state;
    };
    const drain = async (state: {done: boolean}) => {
      for (let i = 0; i < 1000 && !state.done; i += 1) {
        await Promise.resolve();
      }
    };
    const finishLabels = (events: AgentEvent[]) =>
      events.filter(e => e.type === 'tool_call_finished').map(eventLabel);
    const outcomeResults = (events: AgentEvent[]) =>
      events
        .filter(e => e.type === 'tool_call_finished')
        .map(e => (e as any).outcome.result);
    const pageUrl = 'https://example.com/mars';
    const hit = {title: 'Mars', url: pageUrl, snippet: 'The red planet.'};

    beforeEach(() => {
      resetSearchCache();
      resetReadUrlAllowlist();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    it('runs the calls of a batch at once, so the tool phase lasts as long as the slowest', async () => {
      jest.useFakeTimers();
      const fast = timedTalent('fast', 300);
      const slow = timedTalent('slow', 500);
      const engine = batchEngine([
        toolCall('c0', 'fast'),
        toolCall('c1', 'slow'),
      ]);
      const done = collect(run(engine, {fast: fast.talent, slow: slow.talent}));

      await flush();
      expect(fast.execute).toHaveBeenCalledTimes(1);
      expect(slow.execute).toHaveBeenCalledTimes(1);

      await jest.advanceTimersByTimeAsync(499);
      await flush();
      expect(engine.completion).toHaveBeenCalledTimes(1);

      await jest.advanceTimersByTimeAsync(1);
      await flush();
      expect(engine.completion).toHaveBeenCalledTimes(2);
      await done;
    });

    it('holds an early settler until the calls before it finish, and replays in call order', async () => {
      jest.useFakeTimers();
      const first = timedTalent('first', 500);
      const second = timedTalent('second', 100);
      const engine = batchEngine([
        toolCall('c0', 'first'),
        toolCall('c1', 'second'),
      ]);
      const done = collect(
        run(engine, {first: first.talent, second: second.talent}),
      );
      await jest.advanceTimersByTimeAsync(500);
      const events = await done;

      expect(events.map(eventLabel)).toEqual([
        'run_started',
        'step_started',
        'step_finished',
        'tool_call_started c0',
        'tool_call_started c1',
        'tool_call_finished c0',
        'tool_call_finished c1',
        'step_started',
        'step_finished',
        'run_finished',
      ]);
      const followUp = (engine.completion as jest.Mock).mock.calls[1][0];
      expect(followUp.messages.slice(-3)).toEqual([
        expect.objectContaining({
          role: 'assistant',
          tool_calls: [
            expect.objectContaining({id: 'c0'}),
            expect.objectContaining({id: 'c1'}),
          ],
        }),
        {role: 'tool', tool_call_id: 'c0', content: 'first'},
        {role: 'tool', tool_call_id: 'c1', content: 'second'},
      ]);
    });

    it('cancels every call of a batch together on Stop', async () => {
      const controller = new AbortController();
      let fetches = 0;
      global.fetch = abortableFetch({
        onCall: () => {
          fetches += 1;
          if (fetches === 2) {
            controller.abort();
          }
        },
      });
      const webSearch = new WebSearchEngine(
        searchAccess(new TavilyProvider(() => 'key')),
      );
      const engine = batchEngine([
        toolCall('c0', 'web_search', {query: 'mars'}),
        toolCall('c1', 'web_search', {query: 'venus'}),
      ]);

      const events = await collect(
        run(engine, {web_search: webSearch}, controller.signal),
      );

      expect(global.fetch).toHaveBeenCalledTimes(2);
      const finished = events.filter(e => e.type === 'tool_call_finished');
      expect(finished.map(e => (e as any).outcome.result.errorMessage)).toEqual(
        ['cancelled', 'cancelled'],
      );
      expect(events.map(eventLabel)).toEqual([
        'run_started',
        'step_started',
        'step_finished',
        'tool_call_started c0',
        'tool_call_started c1',
        'tool_call_finished c0',
        'tool_call_finished c1',
        'run_finished',
      ]);
    });

    it('refuses a read_url of a URL only a sibling network search returns', async () => {
      const provider: SearchProvider = {
        id: 'tavily',
        search: jest.fn(async () => [hit]),
      };
      const access = searchAccess(provider);
      const engine = batchEngine([
        toolCall('c0', 'web_search', {query: 'mars'}),
        toolCall('c1', 'read_url', {url: pageUrl}),
      ]);

      const events = await collect(
        run(engine, {
          web_search: new WebSearchEngine(access),
          read_url: new ReadUrlEngine(access),
        }),
      );

      const [search, read] = events
        .filter(e => e.type === 'tool_call_finished')
        .map(e => (e as any).outcome.result);
      expect(search.type).toBe('search');
      expect(read.summary).toContain('this URL is not allowed');
      expect(access.readWithDefaultReader).not.toHaveBeenCalled();
    });

    it('allows a read_url of a URL a sibling search returns from the cache', async () => {
      const provider: SearchProvider = {
        id: 'tavily',
        search: jest.fn(async () => []),
      };
      const access = searchAccess(provider);
      setCachedHits('tavily', 'mars', 3, [hit]);
      const engine = batchEngine([
        toolCall('c0', 'web_search', {query: 'mars'}),
        toolCall('c1', 'read_url', {url: pageUrl}),
      ]);

      const events = await collect(
        run(engine, {
          web_search: new WebSearchEngine(access),
          read_url: new ReadUrlEngine(access),
        }),
      );

      const read = events.filter(e => e.type === 'tool_call_finished')[1];
      expect((read as any).outcome.result.type).toBe('text');
      expect(provider.search).not.toHaveBeenCalled();
      expect(access.readWithDefaultReader).toHaveBeenCalledWith(
        pageUrl,
        undefined,
      );
    });

    it('a consumer that stops at a finish waits for the rest of the batch and its side effects', async () => {
      jest.useFakeTimers();
      const calculate = makeTalent('calculate', () => ({
        type: 'text',
        summary: '4',
      }));
      const search = timedTalent('search', 300, () => allowReadUrls([pageUrl]));
      const iterator = run(
        batchEngine([toolCall('c0', 'calculate'), toolCall('c1', 'search')]),
        {calculate, search: search.talent},
      );
      let event = await iterator.next();
      while (!event.done && event.value.type !== 'tool_call_finished') {
        event = await iterator.next();
      }

      let allowedWhenReturned: string | null | undefined;
      const returning = iterator.return(undefined).then(() => {
        allowedWhenReturned = matchReadUrl(pageUrl);
      });
      await flush();
      expect(allowedWhenReturned).toBeUndefined();

      await jest.advanceTimersByTimeAsync(300);
      await returning;
      expect(allowedWhenReturned).toBe(pageUrl);
    });

    it.each(['break', 'throw'])(
      'a consumer that leaves at a finish by %s cancels a running search at once',
      async how => {
        const controller = new AbortController();
        global.fetch = abortableFetch();
        const calculate = makeTalent('calculate', () => ({
          type: 'text',
          summary: '4',
        }));
        const webSearch = new WebSearchEngine(
          searchAccess(new TavilyProvider(() => 'key')),
        );
        const iterator = run(
          batchEngine([
            toolCall('c0', 'calculate'),
            toolCall('c1', 'web_search', {query: 'venus'}),
          ]),
          {calculate, web_search: webSearch},
          controller.signal,
        );
        const leave = async () => {
          for await (const event of iterator) {
            if (eventLabel(event) === 'tool_call_finished c0') {
              if (how === 'break') {
                break;
              }
              throw new Error('store write failed');
            }
          }
        };
        let settled = false;
        leave()
          .catch(() => {})
          .then(() => {
            settled = true;
          });
        await flush();

        expect(settled).toBe(true);
        expect(global.fetch).toHaveBeenCalledTimes(1);
        expect(getCachedHits('tavily', 'venus', 3)).toBeUndefined();
        expect(matchReadUrl(pageUrl)).toBeNull();
        expect(controller.signal.aborted).toBe(false);
      },
    );

    it('a consumer that stops at a start dispatches no call', async () => {
      const first = deferredTalent('first');
      const second = deferredTalent('second');
      const iterator = run(
        batchEngine([toolCall('c0', 'first'), toolCall('c1', 'second')]),
        {first: first.talent, second: second.talent},
      );
      let event = await iterator.next();
      while (!event.done && event.value.type !== 'tool_call_started') {
        event = await iterator.next();
      }

      await iterator.return(undefined);

      expect(first.execute).not.toHaveBeenCalled();
      expect(second.execute).not.toHaveBeenCalled();
    });

    it('runs no call until every start of its batch has been consumed, then starts them in call order', async () => {
      const first = deferredTalent('first');
      const second = deferredTalent('second');
      const iterator = run(
        batchEngine([toolCall('c0', 'first'), toolCall('c1', 'second')]),
        {first: first.talent, second: second.talent},
      );
      let event = await iterator.next();
      while (
        !event.done &&
        eventLabel(event.value) !== 'tool_call_started c1'
      ) {
        event = await iterator.next();
      }
      await flush();
      expect(first.execute).not.toHaveBeenCalled();
      expect(second.execute).not.toHaveBeenCalled();

      const next = iterator.next();
      await flush();
      expect(first.execute).toHaveBeenCalledTimes(1);
      expect(second.execute).toHaveBeenCalledTimes(1);
      expect(first.execute.mock.invocationCallOrder[0]).toBeLessThan(
        second.execute.mock.invocationCallOrder[0],
      );

      first.release();
      second.release();
      expect(eventLabel((await next).value as AgentEvent)).toBe(
        'tool_call_finished c0',
      );
      await iterator.return(undefined);
    });

    it('keeps at most four calls in flight and starts the next queued call as each settles', async () => {
      let inFlight = 0;
      let peak = 0;
      const deferred = [0, 1, 2, 3, 4, 5].map(i => deferredTalent(`t${i}`));
      const talents = Object.fromEntries(
        deferred.map(d => [
          d.talent.name,
          talentWith(d.talent.name, (args, ctx) => {
            inFlight += 1;
            peak = Math.max(peak, inFlight);
            return d.talent.execute(args, ctx).finally(() => {
              inFlight -= 1;
            });
          }),
        ]),
      );
      const called = () => deferred.map(d => d.execute.mock.calls.length > 0);
      const done = track(
        collect(
          run(
            batchEngine(
              deferred.map((d, i) => toolCall(`c${i}`, d.talent.name)),
            ),
            talents,
          ),
        ),
      );

      await flush();
      expect(called()).toEqual([true, true, true, true, false, false]);

      deferred[2].release();
      await flush();
      expect(called()).toEqual([true, true, true, true, true, false]);

      deferred[0].release();
      await flush();
      expect(called()).toEqual([true, true, true, true, true, true]);

      [1, 3, 4, 5].forEach(i => deferred[i].release());
      await drain(done);

      expect(done.done).toBe(true);
      expect(peak).toBeLessThanOrEqual(4);
      expect(finishLabels(done.value!)).toEqual(
        [0, 1, 2, 3, 4, 5].map(i => `tool_call_finished c${i}`),
      );
    });

    it('a Stop with calls still queued never dispatches them and cancels them in call order', async () => {
      const controller = new AbortController();
      global.fetch = abortableFetch();
      const webSearch = new WebSearchEngine(
        searchAccess(new TavilyProvider(() => 'key')),
      );
      const searchExecute = jest.spyOn(webSearch, 'execute');
      const calculate = jest.fn(
        async (): Promise<TalentResult> => ({type: 'text', summary: '4'}),
      );
      const calls = [
        ...[0, 1, 2, 3, 4].map(i =>
          toolCall(`c${i}`, 'web_search', {query: `q${i}`}),
        ),
        ...[5, 6, 7].map(i => toolCall(`c${i}`, 'calculate')),
        toolCall('c8', ''),
      ];
      const done = track(
        collect(
          run(
            batchEngine(calls),
            {
              web_search: webSearch,
              calculate: talentWith('calculate', calculate),
            },
            controller.signal,
          ),
        ),
      );

      await flush();
      expect(global.fetch).toHaveBeenCalledTimes(4);
      expect(calculate).not.toHaveBeenCalled();

      controller.abort();
      await drain(done);

      expect(done.done).toBe(true);
      expect(searchExecute).toHaveBeenCalledTimes(4);
      expect(calculate).not.toHaveBeenCalled();
      expect(global.fetch).toHaveBeenCalledTimes(4);
      const results = outcomeResults(done.value!);
      expect(results.map(r => r.errorMessage)).toEqual(
        Array(9).fill('cancelled'),
      );
      expect(results.slice(4).map(r => r.summary)).toEqual([
        'web_search: cancelled',
        ...Array(3).fill('calculate: cancelled'),
        'Unknown talent (no function name): cancelled',
      ]);
      expect(done.value!.map(eventLabel).slice(-10)).toEqual([
        ...[0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => `tool_call_finished c${i}`),
        'run_finished',
      ]);
    });

    it('a consumer that returns with calls still queued starts none of them', async () => {
      const controller = new AbortController();
      const first = makeTalent('t0', () => ({type: 'text', summary: 't0'}));
      const deferred = [1, 2, 3, 4, 5].map(i => deferredTalent(`t${i}`));
      const iterator = run(
        batchEngine([0, 1, 2, 3, 4, 5].map(i => toolCall(`c${i}`, `t${i}`))),
        {
          t0: first,
          ...Object.fromEntries(deferred.map(d => [d.talent.name, d.talent])),
        },
        controller.signal,
      );
      let event = await iterator.next();
      while (
        !event.done &&
        eventLabel(event.value) !== 'tool_call_finished c0'
      ) {
        event = await iterator.next();
      }

      const returned = track(iterator.return(undefined));
      await flush();

      const [t1, t2, t3, t4, t5] = deferred;
      expect(t5.execute).not.toHaveBeenCalled();
      expect([t1, t2, t3, t4].map(d => d.signal()?.aborted)).toEqual([
        true,
        true,
        true,
        true,
      ]);
      expect(returned.done).toBe(false);

      [t1, t2, t3, t4].forEach(d => d.release());
      await drain(returned);

      expect(returned.done).toBe(true);
      expect(t5.execute).not.toHaveBeenCalled();
      expect(controller.signal.aborted).toBe(false);
    });

    it('a consumer that returns with calls still queued starts none of them when the run has no signal', async () => {
      const first = makeTalent('t0', () => ({type: 'text', summary: 't0'}));
      const deferred = [1, 2, 3, 4, 5].map(i => deferredTalent(`t${i}`));
      const iterator = run(
        batchEngine([0, 1, 2, 3, 4, 5].map(i => toolCall(`c${i}`, `t${i}`))),
        {
          t0: first,
          ...Object.fromEntries(deferred.map(d => [d.talent.name, d.talent])),
        },
      );
      let event = await iterator.next();
      while (
        !event.done &&
        eventLabel(event.value) !== 'tool_call_finished c0'
      ) {
        event = await iterator.next();
      }

      const returned = track(iterator.return(undefined));
      await flush();

      const [t1, t2, t3, t4, t5] = deferred;
      expect(t4.execute).toHaveBeenCalledWith({});
      expect(returned.done).toBe(false);

      [t1, t2, t3, t4].forEach(d => d.release());
      await drain(returned);

      expect(returned.done).toBe(true);
      expect(t5.execute).not.toHaveBeenCalled();
    });

    it('a Stop during the start events runs no local talent and cancels every call in call order', async () => {
      const controller = new AbortController();
      const calculate = jest.fn(
        async (): Promise<TalentResult> => ({type: 'text', summary: '4'}),
      );
      const iterator = run(
        batchEngine(
          [0, 1, 2, 3, 4, 5].map(i => toolCall(`c${i}`, 'calculate')),
        ),
        {calculate: talentWith('calculate', calculate)},
        controller.signal,
      );
      const consume = async () => {
        const events: AgentEvent[] = [];
        for await (const event of iterator) {
          events.push(event);
          if (eventLabel(event) === 'tool_call_started c0') {
            controller.abort();
          }
        }
        return events;
      };
      const done = track(consume());
      await drain(done);

      expect(done.done).toBe(true);
      expect(calculate).not.toHaveBeenCalled();
      const results = outcomeResults(done.value!);
      expect(results.map(r => r.summary)).toEqual(
        Array(6).fill('calculate: cancelled'),
      );
      expect(results.map(r => r.errorMessage)).toEqual(
        Array(6).fill('cancelled'),
      );
      expect(done.value!.map(eventLabel).slice(-7)).toEqual([
        ...[0, 1, 2, 3, 4, 5].map(i => `tool_call_finished c${i}`),
        'run_finished',
      ]);
    });

    it('a Stop between the start events cancels every search without a fetch, finishing in call order', async () => {
      const controller = new AbortController();
      global.fetch = abortableFetch();
      const webSearch = new WebSearchEngine(
        searchAccess(new TavilyProvider(() => 'key')),
      );
      const iterator = run(
        batchEngine([
          toolCall('c0', 'web_search', {query: 'mars'}),
          toolCall('c1', 'web_search', {query: 'venus'}),
        ]),
        {web_search: webSearch},
        controller.signal,
      );
      const events: AgentEvent[] = [];
      for (
        let event = await iterator.next();
        !event.done;
        event = await iterator.next()
      ) {
        events.push(event.value);
        if (eventLabel(event.value) === 'tool_call_started c0') {
          controller.abort();
        }
      }

      expect(global.fetch).not.toHaveBeenCalled();
      expect(events.map(eventLabel)).toEqual([
        'run_started',
        'step_started',
        'step_finished',
        'tool_call_started c0',
        'tool_call_started c1',
        'tool_call_finished c0',
        'tool_call_finished c1',
        'run_finished',
      ]);
      expect(
        events
          .filter(e => e.type === 'tool_call_finished')
          .map(e => (e as any).outcome.result.errorMessage),
      ).toEqual(['cancelled', 'cancelled']);
    });

    describe('when dispatching one call throws', () => {
      const unhandled = jest.fn();

      beforeEach(() => {
        unhandled.mockClear();
        process.on('unhandledRejection', unhandled);
      });

      afterEach(() => {
        process.off('unhandledRejection', unhandled);
      });

      it.each([0, 1])(
        'at index %i, the run ends only after its sibling settles',
        async throwingIndex => {
          const sibling = deferredTalent('slow');
          const names =
            throwingIndex === 0 ? ['boom', 'slow'] : ['slow', 'boom'];
          let settled = false;
          const done = collect(
            runAgent({
              engine: batchEngine(names.map((n, i) => toolCall(`c${i}`, n))),
              initialParams: baseParams,
              allowedTalentNames: names,
              talentLookup: name => {
                if (name === 'boom') {
                  throw new Error('lookup failed');
                }
                return sibling.talent;
              },
              messageId: 'msg',
              triggerMarkers: [],
            }),
          ).then(events => {
            settled = true;
            return events;
          });

          await flush();
          expect(sibling.execute).toHaveBeenCalledTimes(1);
          expect(settled).toBe(false);

          sibling.release();
          const events = await done;
          await new Promise(resolve => setImmediate(resolve));

          expect(events[events.length - 1].type).toBe('run_failed');
          expect(unhandled).not.toHaveBeenCalled();
        },
      );

      it('aborts a running sibling before the run fails', async () => {
        const controller = new AbortController();
        let siblingSignal: AbortSignal | undefined;
        let release!: () => void;
        const sibling = talentWith(
          'slow',
          (_args, ctx) =>
            new Promise<TalentResult>(resolve => {
              siblingSignal = ctx?.signal;
              release = () => resolve({type: 'text', summary: 'slow'});
            }),
        );
        const iterator = runAgent({
          engine: batchEngine([toolCall('c0', 'boom'), toolCall('c1', 'slow')]),
          initialParams: baseParams,
          allowedTalentNames: ['boom', 'slow'],
          talentLookup: name => {
            if (name === 'boom') {
              throw new Error('lookup failed');
            }
            return sibling;
          },
          messageId: 'msg',
          triggerMarkers: [],
          signal: controller.signal,
        });

        let event = await iterator.next();
        while (!event.done && event.value.type !== 'run_failed') {
          event = await iterator.next();
        }

        expect(event.done).toBe(false);
        expect(siblingSignal?.aborted).toBe(true);
        expect(controller.signal.aborted).toBe(false);

        release();
        expect((await iterator.next()).done).toBe(true);
        await new Promise(resolve => setImmediate(resolve));
        expect(unhandled).not.toHaveBeenCalled();
      });
    });
  });
});
