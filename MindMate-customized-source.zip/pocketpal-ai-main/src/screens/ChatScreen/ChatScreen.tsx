import React, {useMemo, useRef, ReactNode, useState} from 'react';
import {StyleSheet, View} from 'react-native';
import {Text} from 'react-native-paper';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import {observer} from 'mobx-react';
import {runInAction} from 'mobx';

import {
  Bubble,
  ChatView,
  ErrorSnackbar,
  ModelErrorReportSheet,
  VoiceMemorySheet,
  VoiceModeControlsContext,
  VoiceModeView,
  VoiceSetupSheet,
  VoiceTeaser,
} from '../../components';
import {PalSheet} from '../../components/PalsSheets';

import {useChatSession, useVoiceMode, useTheme} from '../../hooks';
import {usePendingMessage} from '../../hooks/useDeepLinking';
import {Pal} from '../../types/pal';

import {
  modelStore,
  chatSessionStore,
  palStore,
  serverStore,
  ttsStore,
  uiStore,
  voiceModeStore,
} from '../../store';
import {hasVideoCapability} from '../../utils/pal-capabilities';

import {L10nContext} from '../../utils';
import {
  clampEffort,
  resolveReasoningCapability,
} from '../../utils/reasoningCapability';
import {MessageType} from '../../utils/types';
import {ErrorState} from '../../utils/errors';
import {user, assistant} from '../../utils/chat';

import {VideoPalScreen} from './VideoPalScreen';

const renderBubble = ({
  child,
  message,
  nextMessageInGroup,
  scale,
}: {
  child: ReactNode;
  message: MessageType.Any;
  nextMessageInGroup: boolean;
  scale?: any;
}) => (
  <Bubble
    child={child}
    message={message}
    nextMessageInGroup={nextMessageInGroup}
    scale={scale}
  />
);

export const ChatScreen: React.FC = observer(() => {
  const currentMessageInfo = useRef<{
    createdAt: number;
    id: string;
    sessionId: string;
  } | null>(null);
  const l10n = React.useContext(L10nContext);
  const theme = useTheme();

  const activePalId = chatSessionStore.activePalId;
  const activePal = activePalId
    ? palStore.pals.find(p => p.id === activePalId)
    : undefined;
  const isVideoPal = activePal && hasVideoCapability(activePal);

  // State for pal sheet
  const [isPalSheetVisible, setIsPalSheetVisible] = useState(false);

  // State for model error report sheet
  const [isErrorReportVisible, setIsErrorReportVisible] = useState(false);
  const [errorToReport, setErrorToReport] = useState<ErrorState | null>(null);

  const {handleSendPress, handleStopPress} = useChatSession(
    currentMessageInfo,
    user,
    assistant,
  );

  const voiceMode = useVoiceMode({
    port: {
      send: async (text, onTurnCreated) => {
        await handleSendPress(
          {text, type: 'text'},
          {spoken: true, onTurnCreated},
        );
      },
      stop: () => handleStopPress(),
    },
  });
  const {tapCloud, toggleMute, end, dismissSheet} = voiceMode;
  React.useEffect(() => {
    if (isVideoPal) {
      end();
    }
  }, [isVideoPal, end]);
  const voiceControls = useMemo(
    () => ({tapCloud, toggleMute, end}),
    [tapCloud, toggleMute, end],
  );
  const handleCloseVoiceTeaser = React.useCallback(
    () => dismissSheet('teaser'),
    [dismissSheet],
  );
  const handleCloseVoiceSetup = React.useCallback(
    () => dismissSheet('setup'),
    [dismissSheet],
  );
  const handleCloseVoiceMemory = React.useCallback(
    () => dismissSheet('memory'),
    [dismissSheet],
  );

  // Handle deep linking for message prefill
  const {pendingMessage, clearPendingMessage} = usePendingMessage();

  // Callback handler for opening pal sheet
  const handleOpenPalSheet = React.useCallback((_pal: Pal) => {
    setIsPalSheetVisible(true);
  }, []);

  const handleClosePalSheet = React.useCallback(() => {
    setIsPalSheetVisible(false);
  }, []);

  // Handlers for model error report
  const handleReportModelError = React.useCallback(() => {
    if (modelStore.modelLoadError) {
      setErrorToReport(modelStore.modelLoadError);
      setIsErrorReportVisible(true);
      modelStore.clearModelLoadError();
    }
  }, []);

  const handleCloseErrorReport = React.useCallback(() => {
    setIsErrorReportVisible(false);
    setErrorToReport(null);
  }, []);

  const visionEnabled = modelStore.activeModelCaps.visionActive;

  // Resolver is the single source of truth for reasoning capability.
  // Pill is reachable whenever the model is not known to be non-reasoning
  // (fail-open on 'unknown' so remote + missed-local models are reachable).
  const reasoningCapability = resolveReasoningCapability(
    modelStore.activeModel,
    serverStore.remoteReasoning,
  );
  const thinkingSupported =
    !!modelStore.activeModel && reasoningCapability.isReasoning !== 'no';

  const [thinkingEnabled, setThinkingEnabled] = useState(true);
  const [storedEffort, setStoredEffort] = useState<string | undefined>(
    undefined,
  );
  const reasoningEffort = clampEffort(
    storedEffort,
    reasoningCapability.effortValues,
  );
  const activeSession = chatSessionStore.sessions.find(
    s => s.id === chatSessionStore.activeSessionId,
  );
  React.useEffect(() => {
    let cancelled = false;
    chatSessionStore.getCurrentCompletionSettings().then(settings => {
      if (!cancelled) {
        setThinkingEnabled(settings.enable_thinking ?? true);
        setStoredEffort(settings.reasoning?.effort);
      }
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    chatSessionStore.activeSessionId,
    activeSession?.settingsSource,
    activeSession?.completionSettings,
    chatSessionStore.newChatCompletionSettings,
    chatSessionStore.newChatThinkingOverride,
    chatSessionStore.newChatReasoningEffort,
    activePalId,
  ]);

  // Tool-compatibility one-time banner: when the active Pal declares
  // tools but the loaded model's jinja metadata signals no tool support
  // in any of its slots (see below), surface an inline warning.
  // Persisted per model id so the warning fires at most once.
  React.useEffect(() => {
    const palDeclaresTools =
      activePal?.pact?.talents !== undefined &&
      activePal.pact.talents.length > 0;
    if (!palDeclaresTools) {
      return;
    }
    const model = (modelStore.context as any)?.model;
    const modelId = modelStore.activeModelId;
    if (!model || !modelId) {
      return;
    }
    // Tool support surfaces in four independent places in llama.rn's
    // jinja metadata: defaultCaps.tools/toolCalls (model declares it
    // inline in the default template — Ministral, Llama 3.x, etc.) or
    // toolUse/toolUseCaps (separate tool-use template — Qwen3, etc.).
    // Any one is sufficient; only warn when all four are absent.
    const jinja = model.chatTemplates?.jinja;
    const hasToolSupport =
      !!jinja?.defaultCaps?.tools ||
      !!jinja?.defaultCaps?.toolCalls ||
      !!jinja?.toolUse ||
      !!jinja?.toolUseCaps;
    if (hasToolSupport) {
      return;
    }
    if (uiStore.hasWarnedToolCompat(modelId)) {
      return;
    }
    uiStore.setChatWarning({
      code: 'unknown',
      message: l10n.chat.toolCompatWarning,
      context: 'chat',
      recoverable: true,
      severity: 'warning',
      metadata: {modelId},
    });
    uiStore.markToolCompatWarned(modelId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePalId, modelStore.activeModelId, modelStore.context]);

  // Persist the on/off intent (and optional effort) onto both the local
  // enable_thinking flag and the reasoning carrier so the remote wire path
  // (the profile in src/api/servers/) and the local hook both see it.
  // Preserves pal overrides. No active session: stage on the new-chat
  // override field — the resolver applies it as the last layer and session
  // creation bakes it in, without touching newChatCompletionSettings.
  const persistReasoning = async (enabled: boolean, effort?: string) => {
    const currentSession = chatSessionStore.sessions.find(
      s => s.id === chatSessionStore.activeSessionId,
    );
    if (currentSession) {
      const resolvedSettings =
        await chatSessionStore.getCurrentCompletionSettings();
      await chatSessionStore.updateSessionCompletionSettings({
        ...resolvedSettings,
        enable_thinking: enabled,
        reasoning: {enabled, effort},
      });
    } else {
      runInAction(() => {
        chatSessionStore.newChatThinkingOverride = enabled;
        chatSessionStore.newChatReasoningEffort = effort;
      });
    }
  };

  // Simple on/off pill (effortless models): carries the on/off intent on the
  // reasoning carrier (effort undefined) so remote OFF is not a no-op.
  const handleThinkingToggle = async (enabled: boolean) => {
    await persistReasoning(enabled);
  };

  // Graded pill cycle: off -> values[0] -> ... -> values[n] -> off.
  const handleEffortCycle = async () => {
    const values = reasoningCapability.effortValues;
    if (values.length === 0) {
      return;
    }
    let nextEnabled: boolean;
    let nextEffort: string | undefined;
    if (!thinkingEnabled) {
      nextEnabled = true;
      nextEffort = values[0];
    } else {
      const idx = reasoningEffort ? values.indexOf(reasoningEffort) : -1;
      if (idx < 0 || idx >= values.length - 1) {
        nextEnabled = false;
        nextEffort = undefined;
      } else {
        nextEnabled = true;
        nextEffort = values[idx + 1];
      }
    }
    setThinkingEnabled(nextEnabled);
    setStoredEffort(nextEffort);
    await persistReasoning(nextEnabled, nextEffort);
  };

  // If the active pal is a video pal, show the video pal screen
  if (isVideoPal) {
    return <VideoPalScreen activePal={activePal} />;
  }

  const teaserOpen = voiceMode.sheet?.kind === 'teaser';
  const chatCovered = voiceModeStore.isFullViewOpen || teaserOpen;

  // Otherwise, show the regular chat view
  return (
    <VoiceModeControlsContext.Provider value={voiceControls}>
      <View
        style={styles.chat}
        importantForAccessibility={chatCovered ? 'no-hide-descendants' : 'auto'}
        accessibilityElementsHidden={chatCovered}>
        <ChatView
          renderBubble={renderBubble}
          emptyState={() => <MindMateWelcome theme={theme} />}
          messages={chatSessionStore.currentSessionMessages}
          activePal={activePal}
          onSendPress={handleSendPress}
          onStopPress={handleStopPress}
          onPalSettingsSelect={handleOpenPalSheet}
          user={user}
          isStopVisible={modelStore.inferencing}
          isStreaming={modelStore.isStreaming}
          sendButtonVisibilityMode="always"
          showImageUpload={true}
          isVisionEnabled={visionEnabled}
          initialInputText={pendingMessage || undefined}
          onInitialTextConsumed={clearPendingMessage}
          onVoiceModePress={voiceMode.requestEntry}
          inputProps={{
            showThinkingToggle: thinkingSupported,
            isThinkingEnabled: thinkingEnabled,
            onThinkingToggle: handleThinkingToggle,
            supportsEffort: reasoningCapability.supportsEffort,
            effortValues: reasoningCapability.effortValues,
            reasoningEffort,
            onEffortCycle: handleEffortCycle,
          }}
          textInputProps={{
            placeholder: !modelStore.engine
              ? modelStore.isContextLoading
                ? l10n.chat.loadingModel
                : l10n.chat.modelNotLoaded
              : l10n.chat.typeYourMessage,
          }}
        />
      </View>
      {voiceModeStore.isFullViewOpen && <VoiceModeView />}
      {teaserOpen && (
        <VoiceTeaser
          onGetPlus={voiceMode.getPlus}
          onKeepTyping={voiceMode.keepTyping}
          onClose={handleCloseVoiceTeaser}
        />
      )}
      <VoiceSetupSheet
        isVisible={voiceMode.sheet?.kind === 'setup'}
        onClose={handleCloseVoiceSetup}
        onDone={voiceMode.setupDone}
      />
      <VoiceMemorySheet
        fit={voiceMode.sheet?.kind === 'memory' ? voiceMode.sheet.fit : null}
        chatModelName={modelStore.activeModel?.name ?? ''}
        voiceName={ttsStore.currentVoice?.name ?? ''}
        onClose={handleCloseVoiceMemory}
        onContinue={voiceMode.continueAnyway}
        onChooseSmallerModel={voiceMode.chooseSmallerModel}
      />
      {uiStore.chatWarning && (
        <ErrorSnackbar
          error={uiStore.chatWarning}
          onDismiss={() => uiStore.clearChatWarning()}
        />
      )}
      {modelStore.modelLoadError && (
        <ErrorSnackbar
          error={modelStore.modelLoadError}
          onDismiss={() => modelStore.clearModelLoadError()}
          onReport={handleReportModelError}
        />
      )}
      <ModelErrorReportSheet
        isVisible={isErrorReportVisible}
        onClose={handleCloseErrorReport}
        error={errorToReport}
      />
      {activePal && (
        <PalSheet
          isVisible={isPalSheetVisible}
          onClose={handleClosePalSheet}
          pal={activePal}
        />
      )}
    </VoiceModeControlsContext.Provider>
  );
});

const styles = StyleSheet.create({
  chat: {
    flex: 1,
  },
});


const MindMateWelcome = ({theme}: {theme: any}) => {
  const dark = theme.dark;
  const ink = dark ? '#F5F2FF' : '#171326';
  const muted = dark ? '#A7A1B8' : '#777187';
  const panel = dark ? '#1B1928' : '#FFFFFF';
  const border = dark ? '#302B40' : '#E8E2F3';
  const cards = [
    {icon: 'lightbulb-on-outline', title: 'Learn something', subtitle: 'Break down a difficult topic'},
    {icon: 'creation', title: 'Explore ideas', subtitle: 'Brainstorm something new'},
    {icon: 'lightning-bolt-outline', title: 'Make a plan', subtitle: 'Organize your next steps'},
    {icon: 'pencil-outline', title: 'Improve writing', subtitle: 'Polish words and drafts'},
  ];
  return (
    <View style={welcomeStyles.container}>
      <LinearGradient colors={['#C5A5FF', '#8660E8']} style={welcomeStyles.logo}>
        <Icon name="creation" size={43} color="#171126" />
      </LinearGradient>
      <Text style={[welcomeStyles.eyebrow, {color: '#B99AFB'}]}>YOUR THOUGHT PARTNER</Text>
      <Text style={[welcomeStyles.headline, {color: ink}]}>Think clearly.</Text>
      <Text style={[welcomeStyles.headline, {color: '#A987F5', marginTop: -5}]}>Create freely.</Text>
      <Text style={[welcomeStyles.prompt, {color: muted}]}>What would you like to work on today?</Text>
      <View style={welcomeStyles.grid}>
        {cards.map(card => (
          <View key={card.title} style={[welcomeStyles.card, {backgroundColor: panel, borderColor: border}]}>
            <Icon name={card.icon} size={25} color="#B99AFB" />
            <Text style={[welcomeStyles.cardTitle, {color: ink}]}>{card.title}</Text>
            <Text style={[welcomeStyles.cardSubtitle, {color: muted}]}>{card.subtitle}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

const welcomeStyles = StyleSheet.create({
  container: {flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20, paddingTop: 28, paddingBottom: 150},
  logo: {width: 92, height: 92, borderRadius: 28, alignItems: 'center', justifyContent: 'center', marginBottom: 30},
  eyebrow: {fontSize: 13, fontWeight: '800', letterSpacing: 3, marginBottom: 24},
  headline: {fontSize: 39, lineHeight: 48, fontWeight: '800', letterSpacing: -1.5, textAlign: 'center'},
  prompt: {fontSize: 16, marginTop: 22, marginBottom: 34, textAlign: 'center'},
  grid: {width: '100%', flexDirection: 'row', flexWrap: 'wrap', gap: 12},
  card: {width: '48%', minHeight: 124, borderRadius: 22, borderWidth: 1, padding: 16, justifyContent: 'space-between'},
  cardTitle: {fontSize: 15, fontWeight: '700', marginTop: 13},
  cardSubtitle: {fontSize: 12, marginTop: 5},
});
