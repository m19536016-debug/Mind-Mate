export {SplashScreen} from './SplashScreen';
