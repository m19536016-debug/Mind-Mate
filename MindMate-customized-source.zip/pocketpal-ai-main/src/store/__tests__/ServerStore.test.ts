import {AppState} from 'react-native';
import {runInAction} from 'mobx';

import * as Keychain from 'react-native-keychain';

import * as openaiModule from '../../api/openai';
import * as propsModule from '../../api/llamaServer/props';

// Mock dependencies before importing the store
jest.mock('mobx-persist-store', () => ({
  makePersistable: jest.fn().mockReturnValue(Promise.resolve()),
}));

jest.mock('../../api/openai', () => ({
  fetchModelsWithHeaders: jest.fn(),
  testConnection: jest.fn(),
}));

jest.mock('../../api/llamaServer/props', () => ({
  fetchServerProps: jest.fn(),
  PROPS_TIMEOUT_MS: 5000,
}));

// The store subscribes at import, before the spy below replaces the mock.
const appStateListener: (state: string) => void = (
  AppState.addEventListener as jest.Mock
).mock.calls.find(([event]) => event === 'change')[1];

// Mock AppState.addEventListener
const mockAddEventListener = jest.fn().mockReturnValue({remove: jest.fn()});
jest
  .spyOn(AppState, 'addEventListener')
  .mockImplementation(mockAddEventListener);

// Import the singleton after mocks
import {serverStore} from '../ServerStore';
import {routerModelsBody} from '../../../jest/fixtures/remoteModelList';
import type {RemoteModelInfo} from '../../utils/types';
import type {ServerType} from '../../utils/serverTypes';

// Captured at import time: the constructor runs once, and `clearAllMocks`
// between tests would otherwise erase the only call there ever is.
const persistedProperties: string[] = (
  jest.requireMock('mobx-persist-store').makePersistable as jest.Mock
).mock.calls[0][1].properties;

/** A probe result that resolves the capability tier and nothing else. */

const mockedFetchList = openaiModule.fetchModelsWithHeaders as jest.Mock;
const listOf = (models: unknown[], extra: {hasModelsKey?: true} = {}) => ({
  models,
  headers: {},
  ...extra,
});
const mockedFetchServerProps = propsModule.fetchServerProps as jest.Mock;
const mockedTestConnection = openaiModule.testConnection as jest.Mock;
const {PROPS_TIMEOUT_MS} = propsModule;

describe('ServerStore', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    // Reset store state between tests
    runInAction(() => {
      serverStore.servers = [];
      serverStore.serverModels.clear();
      serverStore.userSelectedModels = [];
      serverStore.isLoading = false;
      serverStore.error = null;
      serverStore.privacyNoticeAcknowledged = false;
      serverStore.remoteReasoning = {};
      serverStore.remoteCaps = {};
      serverStore.listReads = {};
      serverStore.appActive = true;
    });
  });

  describe('initial state', () => {
    it('has empty servers', () => {
      expect(serverStore.servers).toEqual([]);
    });

    it('has isLoading false', () => {
      expect(serverStore.isLoading).toBe(false);
    });

    it('has no error', () => {
      expect(serverStore.error).toBeNull();
    });

    it('has privacyNoticeAcknowledged false', () => {
      expect(serverStore.privacyNoticeAcknowledged).toBe(false);
    });

    it('has empty userSelectedModels', () => {
      expect(serverStore.userSelectedModels).toEqual([]);
    });
  });

  describe('addServer', () => {
    it('adds a server and returns its id', () => {
      const id = serverStore.addServer({
        name: 'Test Server',
        url: 'http://localhost:1234',
      });

      expect(typeof id).toBe('string');
      expect(id).toMatch(/^server-/);
      expect(serverStore.servers).toHaveLength(1);
      expect(serverStore.servers[0].name).toBe('Test Server');
      expect(serverStore.servers[0].url).toBe('http://localhost:1234');
    });

    it('does not auto-fetch models on add', () => {
      serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      expect(mockedFetchList).not.toHaveBeenCalled();
    });

    it('generates unique ids for each server', () => {
      const id1 = serverStore.addServer({
        name: 'Server 1',
        url: 'http://a.com',
      });
      const id2 = serverStore.addServer({
        name: 'Server 2',
        url: 'http://b.com',
      });

      expect(id1).not.toBe(id2);
    });
  });

  describe('updateServer', () => {
    it('updates server properties', () => {
      const id = serverStore.addServer({
        name: 'Original',
        url: 'http://localhost:1234',
      });

      serverStore.updateServer(id, {name: 'Updated'});

      expect(serverStore.servers[0].name).toBe('Updated');
    });

    it('does nothing for non-existent server id', () => {
      serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      serverStore.updateServer('non-existent', {name: 'Updated'});
      expect(serverStore.servers[0].name).toBe('Server');
    });

    it('updates server URL', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      serverStore.updateServer(id, {url: 'http://localhost:5678'});

      expect(serverStore.servers[0].url).toBe('http://localhost:5678');
    });

    describe('capability invalidation', () => {
      const addProbedServer = () => {
        const id = serverStore.addServer({
          name: 'llama',
          url: 'http://localhost:8080',
          serverType: 'llama.cpp',
        });
        runInAction(() => {
          serverStore.remoteCaps[`${id}/m`] = {
            contextLength: 8192,
            supportsVision: true,
          };
          serverStore.remoteCaps['other/m'] = {contextLength: 4096};
          serverStore.serverModels.set(id, [
            {id: 'm', object: 'model', owned_by: 'system'},
          ]);
          serverStore.serverModels.set('other', [
            {id: 'm', object: 'model', owned_by: 'system'},
          ]);
          serverStore.remoteReasoning[`${id}/m`] = {
            isReasoning: 'yes',
            source: 'user',
            supportsEffort: false,
            effortValues: [],
            effortSource: 'none',
          };
        });
        return id;
      };

      it('drops this server caps when the url is repointed', () => {
        const id = addProbedServer();

        expect(
          serverStore.updateServer(id, {url: 'http://localhost:9090'}),
        ).toBe(true);

        expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
        expect(serverStore.remoteCaps['other/m']).toBeDefined();
      });

      it('drops this server caps when the server type changes', () => {
        const id = addProbedServer();

        expect(serverStore.updateServer(id, {serverType: 'LM Studio'})).toBe(
          true,
        );

        expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
      });

      it('drops this server model list when the url is repointed', () => {
        const id = addProbedServer();

        serverStore.updateServer(id, {url: 'http://localhost:9090'});

        // A single-entry list from the old backend would clear the bare-retry
        // gate against a router that serves many models.
        expect(serverStore.serverModels.has(id)).toBe(false);
        expect(serverStore.serverModels.has('other')).toBe(true);
      });

      it('drops this server model list when the server type changes', () => {
        const id = addProbedServer();

        serverStore.updateServer(id, {serverType: 'LM Studio'});

        expect(serverStore.serverModels.has(id)).toBe(false);
      });

      it('keeps reasoning state, which is user-declarable', () => {
        const id = addProbedServer();

        serverStore.updateServer(id, {serverType: 'LM Studio'});

        expect(serverStore.remoteReasoning[`${id}/m`]).toBeDefined();
      });

      it('keeps caps when neither the url nor the server type changes', () => {
        const id = addProbedServer();

        const invalidated = serverStore.updateServer(id, {
          name: 'renamed',
          url: 'http://localhost:8080',
          requestTimeoutMs: 60000,
        });

        expect(invalidated).toBe(false);
        expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
          contextLength: 8192,
          supportsVision: true,
        });
        expect(serverStore.serverModels.has(id)).toBe(true);
      });
    });
  });

  describe('server type normalisation', () => {
    it('maps a hydrated legacy or free-string type to unknown', async () => {
      runInAction(() => {
        serverStore.servers = [
          {
            id: 'srv-1',
            name: 'legacy',
            url: 'http://localhost:8080',
            serverType: '' as ServerType,
          },
          {
            id: 'srv-2',
            name: 'free',
            url: 'http://localhost:8081',
            serverType: 'LLAMA.CPP' as ServerType,
          },
          {id: 'srv-3', name: 'absent', url: 'http://localhost:8082'},
        ];
      });
      mockedFetchList.mockResolvedValue(listOf([]));

      await serverStore.afterHydration();

      expect(serverStore.servers.map(s => s.serverType)).toEqual([
        'unknown',
        'unknown',
        undefined,
      ]);
    });

    it('normalises a hydrated type before the first model fetch', async () => {
      const seen: Array<string | undefined> = [];
      mockedFetchList.mockImplementation(() => {
        seen.push(serverStore.servers[0].serverType);
        return Promise.resolve(listOf([]));
      });
      runInAction(() => {
        serverStore.servers = [
          {
            id: 'srv-1',
            name: 'legacy',
            url: 'http://localhost:8080',
            serverType: '' as ServerType,
          },
        ];
      });

      await serverStore.afterHydration();

      expect(seen).toEqual(['unknown']);
    });

    it('leaves an absent serverType absent on an unrelated update', () => {
      const id = serverStore.addServer({
        name: 'typeless',
        url: 'http://localhost:8080',
      });
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {contextLength: 8192};
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
        ]);
      });

      serverStore.updateServer(id, {name: 'renamed'});

      expect(serverStore.servers[0].serverType).toBeUndefined();
      expect(serverStore.remoteCaps[`${id}/m`]).toBeDefined();
      expect(serverStore.serverModels.has(id)).toBe(true);
    });

    it('keeps caps when a row with no stored type is saved back as unknown', () => {
      const id = serverStore.addServer({
        name: 'typeless',
        url: 'http://localhost:8080',
      });
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {contextLength: 8192};
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
        ]);
      });

      // The server sheet always sends serverType and reads an absent one as
      // 'unknown', so this is what pressing Save with nothing changed sends.
      const invalidated = serverStore.updateServer(id, {
        url: 'http://localhost:8080',
        serverType: 'unknown',
      });

      expect(invalidated).toBe(false);
      expect(serverStore.remoteCaps[`${id}/m`]).toBeDefined();
      expect(serverStore.serverModels.has(id)).toBe(true);
    });

    it('keeps caps when a legacy type is saved back as unknown', () => {
      const id = serverStore.addServer({
        name: 'legacy',
        url: 'http://localhost:8080',
        serverType: '' as ServerType,
      });
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {contextLength: 8192};
      });

      serverStore.updateServer(id, {serverType: 'unknown'});

      expect(serverStore.remoteCaps[`${id}/m`]).toBeDefined();
    });
  });

  describe('removeServer', () => {
    it('removes a server from the list', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      expect(serverStore.servers).toHaveLength(1);

      serverStore.removeServer(id);

      expect(serverStore.servers).toHaveLength(0);
    });

    it('clears server models on removal', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'model-1', object: 'model', owned_by: 'system'},
        ]);
      });

      serverStore.removeServer(id);

      expect(serverStore.serverModels.has(id)).toBe(false);
    });

    it('removes API key from keychain', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      serverStore.removeServer(id);

      expect(Keychain.resetGenericPassword).toHaveBeenCalledWith({
        service: `pocketpal-server-${id}`,
      });
    });

    it('removes all userSelectedModels entries for the server', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.userSelectedModels = [
          {serverId: id, remoteModelId: 'model-a'},
          {serverId: id, remoteModelId: 'model-b'},
          {serverId: 'other-server', remoteModelId: 'model-c'},
        ];
      });

      serverStore.removeServer(id);

      expect(serverStore.userSelectedModels).toEqual([
        {serverId: 'other-server', remoteModelId: 'model-c'},
      ]);
    });
  });

  describe('userSelectedModels', () => {
    describe('addUserSelectedModel', () => {
      it('adds a model selection', () => {
        serverStore.addUserSelectedModel('server-1', 'model-a');

        expect(serverStore.userSelectedModels).toEqual([
          {serverId: 'server-1', remoteModelId: 'model-a'},
        ]);
      });

      it('prevents duplicate entries', () => {
        serverStore.addUserSelectedModel('server-1', 'model-a');
        serverStore.addUserSelectedModel('server-1', 'model-a');

        expect(serverStore.userSelectedModels).toHaveLength(1);
      });

      it('allows same model from different servers', () => {
        serverStore.addUserSelectedModel('server-1', 'model-a');
        serverStore.addUserSelectedModel('server-2', 'model-a');

        expect(serverStore.userSelectedModels).toHaveLength(2);
      });

      it('allows different models from same server', () => {
        serverStore.addUserSelectedModel('server-1', 'model-a');
        serverStore.addUserSelectedModel('server-1', 'model-b');

        expect(serverStore.userSelectedModels).toHaveLength(2);
      });
    });

    describe('removeUserSelectedModel', () => {
      it('removes a specific model selection', () => {
        runInAction(() => {
          serverStore.userSelectedModels = [
            {serverId: 'server-1', remoteModelId: 'model-a'},
            {serverId: 'server-1', remoteModelId: 'model-b'},
          ];
        });

        serverStore.removeUserSelectedModel('server-1', 'model-a');

        expect(serverStore.userSelectedModels).toEqual([
          {serverId: 'server-1', remoteModelId: 'model-b'},
        ]);
      });

      it('does nothing when entry does not exist', () => {
        runInAction(() => {
          serverStore.userSelectedModels = [
            {serverId: 'server-1', remoteModelId: 'model-a'},
          ];
        });

        serverStore.removeUserSelectedModel('server-1', 'non-existent');

        expect(serverStore.userSelectedModels).toHaveLength(1);
      });
    });

    describe('getUserSelectedModelsForServer', () => {
      it('returns models for a specific server', () => {
        runInAction(() => {
          serverStore.userSelectedModels = [
            {serverId: 'server-1', remoteModelId: 'model-a'},
            {serverId: 'server-2', remoteModelId: 'model-b'},
            {serverId: 'server-1', remoteModelId: 'model-c'},
          ];
        });

        const result = serverStore.getUserSelectedModelsForServer('server-1');

        expect(result).toEqual([
          {serverId: 'server-1', remoteModelId: 'model-a'},
          {serverId: 'server-1', remoteModelId: 'model-c'},
        ]);
      });

      it('returns empty array when no models for server', () => {
        const result =
          serverStore.getUserSelectedModelsForServer('non-existent');

        expect(result).toEqual([]);
      });
    });
  });

  describe('removeServerIfOrphaned', () => {
    it('removes server when no user-selected models reference it', () => {
      const id = serverStore.addServer({
        name: 'Orphan Server',
        url: 'http://localhost:1234',
      });

      // No userSelectedModels reference this server
      serverStore.removeServerIfOrphaned(id);

      expect(serverStore.servers).toHaveLength(0);
    });

    it('keeps server when user-selected models still reference it', () => {
      const id = serverStore.addServer({
        name: 'Active Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.userSelectedModels = [
          {serverId: id, remoteModelId: 'model-a'},
        ];
      });

      serverStore.removeServerIfOrphaned(id);

      expect(serverStore.servers).toHaveLength(1);
    });

    it('cleans up API key when removing orphaned server', () => {
      const id = serverStore.addServer({
        name: 'Orphan',
        url: 'http://localhost:1234',
      });

      serverStore.removeServerIfOrphaned(id);

      expect(Keychain.resetGenericPassword).toHaveBeenCalledWith({
        service: `pocketpal-server-${id}`,
      });
    });
  });

  describe('listCaps', () => {
    const addRouter = (serverType: ServerType = 'llama.cpp') => {
      const id = serverStore.addServer({
        name: 'router',
        url: 'http://localhost:8080',
        serverType,
      });
      runInAction(() => {
        serverStore.serverModels.set(
          id,
          routerModelsBody.data as RemoteModelInfo[],
        );
      });
      return id;
    };

    it('answers for every fetched model, keyed as a remote model id is', () => {
      const id = addRouter();

      expect(serverStore.listCaps[`${id}/gemma-4-e2b`]).toEqual({
        tier: 'list',
        supportsVision: true,
        contextLength: 8192,
      });
    });

    it('derives from the fetch alone for a newly added llama.cpp server', async () => {
      mockedFetchList.mockResolvedValue(
        listOf(routerModelsBody.data as RemoteModelInfo[]),
      );
      const id = serverStore.addServer({
        name: 'router',
        url: 'http://localhost:8080',
        serverType: 'llama.cpp',
      });

      await serverStore.fetchModelsForServer(id);

      expect(serverStore.listCaps[`${id}/gemma-4-e2b`]).toEqual({
        tier: 'list',
        supportsVision: true,
        contextLength: 8192,
      });
      expect(mockedFetchServerProps).not.toHaveBeenCalled();
    });

    it('recomputes when a fetch replaces the list', () => {
      const id = addRouter();
      expect(Object.keys(serverStore.listCaps)).toHaveLength(5);

      runInAction(() => {
        serverStore.serverModels.set(id, []);
      });

      expect(Object.keys(serverStore.listCaps)).toHaveLength(0);
    });

    it('reads nothing off a server that is not llama.cpp', () => {
      const id = addRouter('Ollama');

      expect(serverStore.listCaps[`${id}/gemma-4-e2b`]).toEqual({
        tier: 'list',
      });
    });

    it('empties when the url changes, along with the models it derived from', () => {
      const id = addRouter();

      serverStore.updateServer(id, {url: 'http://localhost:9090'});

      expect(serverStore.listCaps).toEqual({});
    });

    it('is not persisted', () => {
      expect(persistedProperties).toEqual([
        'servers',
        'privacyNoticeAcknowledged',
        'userSelectedModels',
        'remoteReasoning',
        'remoteCaps',
      ]);
    });
  });

  describe('getModelsNotYetAdded', () => {
    it('returns all models when none are user-selected', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'model-a', object: 'model', owned_by: 'system'},
          {id: 'model-b', object: 'model', owned_by: 'system'},
        ]);
      });

      const result = serverStore.getModelsNotYetAdded(id);

      expect(result).toHaveLength(2);
      expect(result.map(m => m.id)).toEqual(['model-a', 'model-b']);
    });

    it('filters out already user-selected models', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'model-a', object: 'model', owned_by: 'system'},
          {id: 'model-b', object: 'model', owned_by: 'system'},
          {id: 'model-c', object: 'model', owned_by: 'system'},
        ]);
        serverStore.userSelectedModels = [
          {serverId: id, remoteModelId: 'model-a'},
          {serverId: id, remoteModelId: 'model-c'},
        ];
      });

      const result = serverStore.getModelsNotYetAdded(id);

      expect(result).toHaveLength(1);
      expect(result[0].id).toBe('model-b');
    });

    it('returns empty array when all models are selected', () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'model-a', object: 'model', owned_by: 'system'},
        ]);
        serverStore.userSelectedModels = [
          {serverId: id, remoteModelId: 'model-a'},
        ];
      });

      const result = serverStore.getModelsNotYetAdded(id);

      expect(result).toHaveLength(0);
    });

    it('returns empty array for server with no models fetched', () => {
      const result = serverStore.getModelsNotYetAdded('non-existent');

      expect(result).toEqual([]);
    });
  });

  describe('API key management', () => {
    it('setApiKey stores key in Keychain', async () => {
      await serverStore.setApiKey('server-1', 'sk-test-key');

      expect(Keychain.setGenericPassword).toHaveBeenCalledWith(
        'apiKey',
        'sk-test-key',
        {service: 'pocketpal-server-server-1'},
      );
    });

    it('getApiKey retrieves key from Keychain', async () => {
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce({
        password: 'sk-stored-key',
        username: 'apiKey',
      });

      const key = await serverStore.getApiKey('server-1');

      expect(key).toBe('sk-stored-key');
      expect(Keychain.getGenericPassword).toHaveBeenCalledWith({
        service: 'pocketpal-server-server-1',
      });
    });

    it('getApiKey returns undefined when no key is stored', async () => {
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      const key = await serverStore.getApiKey('server-no-key');
      expect(key).toBeUndefined();
    });

    it('removeApiKey resets Keychain entry', async () => {
      await serverStore.removeApiKey('server-1');

      expect(Keychain.resetGenericPassword).toHaveBeenCalledWith({
        service: 'pocketpal-server-server-1',
      });
    });

    it('setApiKey handles Keychain errors gracefully', async () => {
      (Keychain.setGenericPassword as jest.Mock).mockRejectedValueOnce(
        new Error('Keychain error'),
      );
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation();

      // Should not throw
      await serverStore.setApiKey('server-1', 'key');

      consoleSpy.mockRestore();
    });

    it('getApiKey handles Keychain errors gracefully', async () => {
      (Keychain.getGenericPassword as jest.Mock).mockRejectedValueOnce(
        new Error('Keychain error'),
      );
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation();

      const key = await serverStore.getApiKey('server-1');
      expect(key).toBeUndefined();

      consoleSpy.mockRestore();
    });
  });

  describe('fetchModelsForServer', () => {
    it('fetches models and stores them in serverModels map', async () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });
      jest.clearAllMocks();

      const mockModels = [
        {id: 'llama-7b', object: 'model', owned_by: 'system'},
        {id: 'codellama', object: 'model', owned_by: 'library'},
      ];
      mockedFetchList.mockResolvedValueOnce(listOf(mockModels));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      await serverStore.fetchModelsForServer(id);

      expect(serverStore.serverModels.get(id)).toEqual(mockModels);
      expect(serverStore.isLoading).toBe(false);
      expect(serverStore.error).toBeNull();
    });

    it('sets error on failure', async () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });
      jest.clearAllMocks();

      mockedFetchList.mockRejectedValueOnce(new Error('Connection refused'));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      await serverStore.fetchModelsForServer(id);

      expect(serverStore.error).toBe('Connection refused');
      expect(serverStore.isLoading).toBe(false);
    });

    it('skips fetch for non-existent server id', async () => {
      await serverStore.fetchModelsForServer('non-existent');

      expect(mockedFetchList).not.toHaveBeenCalled();
    });

    it('forwards the server requestTimeoutMs raw to the list request', async () => {
      const id = serverStore.addServer({
        name: 'Slow Server',
        url: 'http://localhost:1234',
        requestTimeoutMs: 600000,
      });
      jest.clearAllMocks();

      mockedFetchList.mockResolvedValueOnce(listOf([]));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      await serverStore.fetchModelsForServer(id);

      expect(mockedFetchList).toHaveBeenCalledWith(
        'http://localhost:1234',
        undefined,
        600000,
      );
    });

    // A server persisted without requestTimeoutMs forwards undefined (raw)
    // without crashing; defaults apply downstream in openai.ts.
    it('forwards undefined requestTimeoutMs without crashing', async () => {
      const id = serverStore.addServer({
        name: 'Legacy Server',
        url: 'http://localhost:1234',
      });
      jest.clearAllMocks();

      mockedFetchList.mockResolvedValueOnce(listOf([]));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      await serverStore.fetchModelsForServer(id);

      expect(mockedFetchList).toHaveBeenCalledWith(
        'http://localhost:1234',
        undefined,
        undefined,
      );
      expect(serverStore.error).toBeNull();
    });

    it('updates lastConnected timestamp on success', async () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });
      jest.clearAllMocks();

      mockedFetchList.mockResolvedValueOnce(listOf([]));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      const before = Date.now();
      await serverStore.fetchModelsForServer(id);

      const server = serverStore.servers.find(s => s.id === id);
      expect(server!.lastConnected).toBeGreaterThanOrEqual(before);
    });

    describe('when the url moves while the list is in flight', () => {
      const pendingFetch = () => {
        let resolve!: (value: unknown) => void;
        mockedFetchList.mockReturnValueOnce(
          new Promise(r => {
            resolve = r;
          }),
        );
        return (models: any[]) => resolve(listOf(models));
      };
      const models = (id: string) => [
        {id, object: 'model', owned_by: 'system'},
      ];
      const addServer = () => {
        const id = serverStore.addServer({
          name: 'Server',
          url: 'http://localhost:8080',
        });
        jest.clearAllMocks();
        return id;
      };
      const started = () =>
        new Promise<void>(resolve => {
          const check = () =>
            mockedFetchList.mock.calls.length > 0
              ? resolve()
              : setImmediate(check);
          check();
        });

      it('drops a list fetched from the url the server left', async () => {
        const id = addServer();
        const resolveA = pendingFetch();
        const fetchA = serverStore.fetchModelsForServer(id);
        await started();

        serverStore.updateServer(id, {url: 'http://localhost:9090'});
        resolveA(models('from-a'));
        await fetchA;

        expect(serverStore.serverModels.has(id)).toBe(false);
        expect(serverStore.servers[0].lastConnected).toBeUndefined();
        expect(serverStore.isLoading).toBe(false);
      });

      it('drops a failure from the url the server left', async () => {
        const id = addServer();
        let rejectA!: (error: Error) => void;
        mockedFetchList.mockReturnValueOnce(
          new Promise((_, reject) => {
            rejectA = reject;
          }),
        );
        const fetchA = serverStore.fetchModelsForServer(id);
        await started();

        serverStore.updateServer(id, {url: 'http://localhost:9090'});
        rejectA(new Error('Connection refused'));
        await fetchA;

        expect(serverStore.error).toBeNull();
        expect(serverStore.isLoading).toBe(false);
      });

      it('keeps only the list from the url saved last', async () => {
        const id = addServer();
        serverStore.updateServer(id, {url: 'http://localhost:9090'});
        const resolveB = pendingFetch();
        const fetchB = serverStore.fetchModelsForServer(id);
        await started();

        serverStore.updateServer(id, {url: 'http://localhost:8080'});
        const resolveA = pendingFetch();
        const fetchA = serverStore.fetchModelsForServer(id);

        resolveB(models('from-b'));
        await fetchB;
        expect(serverStore.serverModels.has(id)).toBe(false);

        resolveA(models('from-a'));
        await fetchA;
        expect(serverStore.serverModels.get(id)).toEqual(models('from-a'));
        expect(serverStore.isLoading).toBe(false);
      });

      it('writes nothing for a server removed in flight', async () => {
        const id = addServer();
        const resolveA = pendingFetch();
        const fetchA = serverStore.fetchModelsForServer(id);
        await started();

        serverStore.removeServer(id);
        resolveA(models('from-a'));
        await fetchA;

        expect(serverStore.serverModels.has(id)).toBe(false);
        expect(serverStore.isLoading).toBe(false);
      });
    });

    it('issues no /props request when fetching the models list', async () => {
      const id = serverStore.addServer({
        name: 'llama server',
        url: 'http://localhost:8080',
        serverType: 'llama.cpp',
      });
      jest.clearAllMocks();

      const mockModels = [{id: 'm', object: 'model', owned_by: 'system'}];
      mockedFetchList.mockResolvedValueOnce(listOf(mockModels));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      await serverStore.fetchModelsForServer(id);
      await new Promise(setImmediate);

      // Capabilities are per model, so listing a server's models discovers
      // none of them.
      expect(mockedFetchServerProps).not.toHaveBeenCalled();
      expect(serverStore.serverModels.get(id)).toEqual(mockModels);
      expect(serverStore.remoteCaps).toEqual({});
    });
  });

  describe('list read record', () => {
    const rows = (id: string) => [{id, object: 'model', owned_by: 'system'}];
    const addServer = () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:8080',
      });
      jest.clearAllMocks();
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValue(false);
      return id;
    };
    const deferred = () => {
      let resolve!: (value: unknown) => void;
      let reject!: (error: Error) => void;
      mockedFetchList.mockReturnValueOnce(
        new Promise((res, rej) => {
          resolve = res;
          reject = rej;
        }),
      );
      return {resolve, reject};
    };

    it('stamps a read with the counter value taken at its start', async () => {
      const id = addServer();
      const before = serverStore.readSeq;
      mockedFetchList.mockResolvedValueOnce(
        listOf(rows('a'), {hasModelsKey: true}),
      );

      const pending = serverStore.fetchModelsForServer(id);
      expect(serverStore.readSeq).toBe(before + 1);
      await expect(pending).resolves.toEqual({ok: true});

      expect(serverStore.listReads[id]).toEqual({
        seq: before + 1,
        hasModelsKey: true,
        stale: false,
      });
    });

    it('records a body without a models key as such', async () => {
      const id = addServer();
      mockedFetchList.mockResolvedValueOnce(listOf(rows('a')));

      await serverStore.fetchModelsForServer(id);

      expect(serverStore.listReads[id].hasModelsKey).toBe(false);
    });

    it('keeps the newer read when an older one answers after it', async () => {
      const id = addServer();
      const older = deferred();
      const olderRead = serverStore.fetchModelsForServer(id);
      mockedFetchList.mockResolvedValueOnce(listOf(rows('newer')));
      await serverStore.fetchModelsForServer(id);
      const installed = serverStore.listReads[id];

      older.resolve(listOf(rows('older'), {hasModelsKey: true}));
      await olderRead;

      expect(serverStore.serverModels.get(id)).toEqual(rows('newer'));
      expect(serverStore.listReads[id]).toEqual(installed);
    });

    it('does not mark the list stale when an older read fails after a newer success', async () => {
      const id = addServer();
      const older = deferred();
      const olderRead = serverStore.fetchModelsForServer(id);
      mockedFetchList.mockResolvedValueOnce(listOf(rows('newer')));
      await serverStore.fetchModelsForServer(id);

      older.reject(new Error('Connection refused'));
      await expect(olderRead).resolves.toEqual({
        ok: false,
        error: 'Connection refused',
      });

      expect(serverStore.listReads[id].stale).toBe(false);
    });

    it('marks the list stale on a newer failure and keeps its rows', async () => {
      const id = addServer();
      mockedFetchList.mockResolvedValueOnce(listOf(rows('a')));
      await serverStore.fetchModelsForServer(id);

      mockedFetchList.mockRejectedValueOnce(new Error('Network error'));
      await serverStore.fetchModelsForServer(id);

      expect(serverStore.listReads[id].stale).toBe(true);
      expect(serverStore.serverModels.get(id)).toEqual(rows('a'));
    });

    it('drops the record with the list on an invalidating update', async () => {
      const id = addServer();
      mockedFetchList.mockResolvedValueOnce(listOf(rows('a')));
      await serverStore.fetchModelsForServer(id);

      serverStore.updateServer(id, {name: 'Renamed'});
      expect(serverStore.listReads[id]).toBeDefined();

      serverStore.updateServer(id, {url: 'http://localhost:9090'});
      expect(serverStore.listReads[id]).toBeUndefined();
      expect(serverStore.serverModels.has(id)).toBe(false);
    });

    it('drops the record with the list on removal', async () => {
      const id = addServer();
      mockedFetchList.mockResolvedValueOnce(listOf(rows('a')));
      await serverStore.fetchModelsForServer(id);

      serverStore.removeServer(id);

      expect(serverStore.listReads[id]).toBeUndefined();
    });

    it('persists neither the record, the counter nor the foreground flag', () => {
      for (const field of ['listReads', 'readCounter', 'appActive']) {
        expect(persistedProperties).not.toContain(field);
      }
    });
  });

  describe('foreground flag', () => {
    it('follows every app state transition', () => {
      appStateListener('background');
      expect(serverStore.appActive).toBe(false);

      appStateListener('active');
      expect(serverStore.appActive).toBe(true);

      appStateListener('inactive');
      expect(serverStore.appActive).toBe(false);
    });
  });

  describe('fetchAllRemoteModels', () => {
    it('fetches models for all servers', async () => {
      serverStore.addServer({
        name: 'Server 1',
        url: 'http://a.com',
      });
      serverStore.addServer({
        name: 'Server 2',
        url: 'http://b.com',
      });
      serverStore.addServer({
        name: 'Server 3',
        url: 'http://c.com',
      });
      jest.clearAllMocks();

      mockedFetchList.mockResolvedValue(listOf([]));
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValue(false);

      await serverStore.fetchAllRemoteModels();

      expect(mockedFetchList).toHaveBeenCalledTimes(3);
    });

    it('does nothing when no servers exist', async () => {
      jest.clearAllMocks();

      await serverStore.fetchAllRemoteModels();

      expect(mockedFetchList).not.toHaveBeenCalled();
    });
  });

  describe('testServerConnection', () => {
    it('tests connection for existing server', async () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      mockedTestConnection.mockResolvedValueOnce({ok: true, modelCount: 5});
      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);

      const result = await serverStore.testServerConnection(id);

      expect(result).toEqual({ok: true, modelCount: 5});
      expect(mockedTestConnection).toHaveBeenCalledWith(
        'http://localhost:1234',
        undefined,
        undefined,
      );
    });

    it('returns error for non-existent server', async () => {
      const result = await serverStore.testServerConnection('non-existent');

      expect(result).toEqual({
        ok: false,
        modelCount: 0,
        error: 'Server not found',
      });
    });

    it('forwards the server requestTimeoutMs to testConnection', async () => {
      const id = serverStore.addServer({
        name: 'Slow Server',
        url: 'http://localhost:1234',
        requestTimeoutMs: 600000,
      });

      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce(false);
      mockedTestConnection.mockResolvedValueOnce({ok: true, modelCount: 2});

      await serverStore.testServerConnection(id);

      expect(mockedTestConnection).toHaveBeenCalledWith(
        'http://localhost:1234',
        undefined,
        600000,
      );
    });

    it('passes API key to testConnection', async () => {
      const id = serverStore.addServer({
        name: 'Server',
        url: 'http://localhost:1234',
      });

      (Keychain.getGenericPassword as jest.Mock).mockResolvedValueOnce({
        password: 'sk-key',
        username: 'apiKey',
      });
      mockedTestConnection.mockResolvedValueOnce({ok: true, modelCount: 3});

      await serverStore.testServerConnection(id);

      expect(mockedTestConnection).toHaveBeenCalledWith(
        'http://localhost:1234',
        'sk-key',
        undefined,
      );
    });
  });

  describe('acknowledgePrivacyNotice', () => {
    it('sets privacyNoticeAcknowledged to true', () => {
      expect(serverStore.privacyNoticeAcknowledged).toBe(false);

      serverStore.acknowledgePrivacyNotice();

      expect(serverStore.privacyNoticeAcknowledged).toBe(true);
    });
  });

  describe('AppState listener', () => {
    it('has setupAppStateListener method in the store', () => {
      // The AppState listener is registered during constructor.
      // Since the singleton is created at module load time (before spy),
      // we verify indirectly that the store has the subscription set up.
      // The constructor calls setupAppStateListener() which creates the subscription.
      expect(serverStore).toBeDefined();
    });
  });

  describe('remote reasoning capability', () => {
    const key = 'server-1/gpt-x';

    it('starts empty and hydrating without the field does not crash', () => {
      expect(serverStore.remoteReasoning).toEqual({});
    });

    it('recordRemoteReasoningObserved flips axis-1 to learned yes', () => {
      serverStore.recordRemoteReasoningObserved(key);
      expect(serverStore.remoteReasoning[key]).toMatchObject({
        isReasoning: 'yes',
        source: 'learned',
        supportsEffort: false,
      });
    });

    it('recordRemoteReasoningObserved is idempotent once yes', () => {
      serverStore.recordRemoteReasoningObserved(key);
      const first = serverStore.remoteReasoning[key];
      serverStore.recordRemoteReasoningObserved(key);
      expect(serverStore.remoteReasoning[key]).toBe(first);
    });

    it('recordRemoteReasoningObserved never overrides a user declaration', () => {
      runInAction(() => {
        serverStore.remoteReasoning[key] = {
          isReasoning: 'no',
          source: 'user',
          supportsEffort: false,
          effortValues: [],
          effortSource: 'none',
        };
      });
      serverStore.recordRemoteReasoningObserved(key);
      expect(serverStore.remoteReasoning[key].source).toBe('user');
      expect(serverStore.remoteReasoning[key].isReasoning).toBe('no');
    });

    it('setRemoteReasoningOverride writes a user-sourced capability', () => {
      serverStore.setRemoteReasoningOverride(key, {
        isReasoning: 'yes',
        source: 'user',
        supportsEffort: true,
        effortValues: ['low', 'high'],
        effortSource: 'user',
      });
      expect(serverStore.remoteReasoning[key]).toMatchObject({
        source: 'user',
        supportsEffort: true,
      });
    });

    it('removeServer drops reasoning entries keyed by that server', () => {
      const id = serverStore.addServer({name: 'A', url: 'http://x'});
      runInAction(() => {
        serverStore.remoteReasoning[`${id}/m1`] = {
          isReasoning: 'yes',
          source: 'learned',
          supportsEffort: false,
          effortValues: [],
          effortSource: 'none',
        };
        serverStore.remoteReasoning['other-server/m2'] = {
          isReasoning: 'yes',
          source: 'learned',
          supportsEffort: false,
          effortValues: [],
          effortSource: 'none',
        };
      });
      serverStore.removeServer(id);
      expect(serverStore.remoteReasoning[`${id}/m1`]).toBeUndefined();
      expect(serverStore.remoteReasoning['other-server/m2']).toBeDefined();
    });

    it('addServer persists a user-selected serverType pass-through', () => {
      const id = serverStore.addServer({
        name: 'A',
        url: 'http://x',
        serverType: 'Ollama',
      });
      expect(serverStore.servers.find(s => s.id === id)?.serverType).toBe(
        'Ollama',
      );
    });
  });

  describe('fetchRemoteModelCaps', () => {
    const addLlamaServer = (overrides: any = {}) =>
      serverStore.addServer({
        name: 'llama server',
        url: 'http://localhost:8080',
        serverType: 'llama.cpp',
        ...overrides,
      });

    it.each([
      ['llama.cpp', 1],
      ['LM Studio', 0],
      ['Ollama', 0],
      ['OpenAI', 0],
      ['vLLM', 0],
      ['unknown', 0],
      ['', 0],
      [undefined, 0],
      ['LLAMA.CPP', 0],
    ])('probes /props for server type %j: %d call(s)', async (type, calls) => {
      const id = addLlamaServer({serverType: type});
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValue({contextLength: 4096});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).toHaveBeenCalledTimes(calls);
    });

    it('writes the scoped probe result under the full model id', async () => {
      const id = addLlamaServer({requestTimeoutMs: 20000});
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({
        contextLength: 8192,
        supportsVision: true,
      });

      await serverStore.fetchRemoteModelCaps(id, 'gemma-4-e2b');

      // A server timeout longer than the probe bound is clamped down to it.
      expect(mockedFetchServerProps).toHaveBeenCalledTimes(1);
      expect(mockedFetchServerProps).toHaveBeenCalledWith(
        'http://localhost:8080',
        undefined,
        PROPS_TIMEOUT_MS,
        'gemma-4-e2b',
      );
      expect(serverStore.remoteCaps[`${id}/gemma-4-e2b`]).toEqual({
        contextLength: 8192,
        supportsVision: true,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('honours a server timeout shorter than the probe bound', async () => {
      const id = addLlamaServer({requestTimeoutMs: 1500});
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({contextLength: 8192});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).toHaveBeenCalledWith(
        'http://localhost:8080',
        undefined,
        1500,
        'm',
      );
    });

    it('keys by the raw model id even when it contains a slash', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({supportsVision: false});

      await serverStore.fetchRemoteModelCaps(id, 'unsloth/gemma-3-4b');

      // Encoding belongs to the request, not the key.
      expect(serverStore.remoteCaps[`${id}/unsloth/gemma-3-4b`]).toEqual({
        supportsVision: false,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('does not let a sibling model inherit another model caps', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({
        contextLength: 8192,
        supportsVision: true,
      });
      await serverStore.fetchRemoteModelCaps(id, 'gemma-4-e2b');

      mockedFetchServerProps.mockResolvedValueOnce({
        contextLength: 4096,
        supportsVision: false,
      });
      await serverStore.fetchRemoteModelCaps(id, 'gemma-3-4b');

      expect(serverStore.remoteCaps[`${id}/gemma-4-e2b`]).toEqual({
        contextLength: 8192,
        supportsVision: true,
        probedUrl: 'http://localhost:8080',
      });
      expect(serverStore.remoteCaps[`${id}/gemma-3-4b`]).toEqual({
        contextLength: 4096,
        supportsVision: false,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('merges field-wise so a partial result never blanks a known field', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {
          contextLength: 8192,
          supportsVision: true,
          probedUrl: 'http://localhost:8080',
        };
      });
      mockedFetchServerProps.mockResolvedValueOnce({supportsVision: false});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        contextLength: 8192,
        supportsVision: false,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('replaces, not merges, an entry probed against another backend', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {
          contextLength: 8192,
          supportsVision: true,
          probedUrl: 'http://localhost:9090',
        };
      });
      mockedFetchServerProps.mockResolvedValueOnce({supportsVision: false});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      // Carrying the old context length across would leave one entry
      // describing two backends and labelled as one of them.
      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        supportsVision: false,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('writes when only the probed backend changed', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m`] = {
          contextLength: 8192,
          probedUrl: 'http://localhost:9090',
        };
      });
      mockedFetchServerProps.mockResolvedValueOnce({contextLength: 8192});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      // Same numbers, different backend — the no-op short-circuit must not
      // swallow this or the entry keeps claiming the old url.
      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        contextLength: 8192,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('leaves a prior entry untouched when the probe yields nothing', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
          {id: 'other', object: 'model', owned_by: 'system'},
        ]);
        serverStore.remoteCaps[`${id}/m`] = {
          contextLength: 8192,
          supportsVision: true,
        };
      });
      mockedFetchServerProps.mockResolvedValueOnce({});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        contextLength: 8192,
        supportsVision: true,
      });
    });

    it('retries bare when the server serves only the probed model', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
        ]);
      });
      mockedFetchServerProps
        .mockResolvedValueOnce({})
        .mockResolvedValueOnce({contextLength: 4096, supportsVision: true});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).toHaveBeenCalledTimes(2);
      expect(mockedFetchServerProps).toHaveBeenLastCalledWith(
        'http://localhost:8080',
        undefined,
        PROPS_TIMEOUT_MS,
      );
      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        contextLength: 4096,
        supportsVision: true,
        probedUrl: 'http://localhost:8080',
      });
    });

    it('stops after the bare retry when neither answer describes a model', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
        ]);
      });
      mockedFetchServerProps
        .mockResolvedValueOnce({})
        .mockResolvedValueOnce({});

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).toHaveBeenCalledTimes(2);
      expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
    });

    it.each([
      [
        'a multi-model list',
        Array.from({length: 45}, (_, i) => ({
          id: `m${i}`,
          object: 'model',
          owned_by: 'system',
        })),
      ],
      [
        'a single non-matching model',
        [{id: 'other', object: 'model', owned_by: 'system'}],
      ],
      ['an empty list', []],
      ['an unknown list', undefined],
    ])('issues no bare retry against %s', async (_label, models: any) => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      runInAction(() => {
        if (models) {
          serverStore.serverModels.set(id, models);
        }
      });
      mockedFetchServerProps.mockResolvedValueOnce({});

      await serverStore.fetchRemoteModelCaps(id, 'm0');

      // A bare probe on a multi-model server describes whichever model is
      // resident, so it must not be attributed to the one being probed.
      expect(mockedFetchServerProps).toHaveBeenCalledTimes(1);
      expect(serverStore.remoteCaps[`${id}/m0`]).toBeUndefined();
    });

    it('uses a supplied api key instead of reading the keychain', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      const getApiKey = jest.spyOn(serverStore, 'getApiKey');
      mockedFetchServerProps.mockResolvedValueOnce({contextLength: 8192});

      await serverStore.fetchRemoteModelCaps(id, 'm', 'sk-test');

      expect(getApiKey).not.toHaveBeenCalled();
      expect(mockedFetchServerProps).toHaveBeenCalledWith(
        'http://localhost:8080',
        'sk-test',
        PROPS_TIMEOUT_MS,
        'm',
      );
      getApiKey.mockRestore();
    });

    it('reads the keychain when the caller supplies no key', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      // A keyless server resolves to undefined, which is indistinguishable
      // from "not supplied" — the read happens either way.
      const getApiKey = jest
        .spyOn(serverStore, 'getApiKey')
        .mockResolvedValue(undefined);
      mockedFetchServerProps.mockResolvedValueOnce({contextLength: 8192});

      await serverStore.fetchRemoteModelCaps(id, 'm', undefined);

      expect(getApiKey).toHaveBeenCalledWith(id);
      expect(mockedFetchServerProps).toHaveBeenCalledWith(
        'http://localhost:8080',
        undefined,
        PROPS_TIMEOUT_MS,
        'm',
      );
      getApiKey.mockRestore();
    });

    it('does not resurrect caps for a server removed mid-probe', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps.mockImplementationOnce(async () => {
        serverStore.removeServer(id);
        return {contextLength: 8192, supportsVision: true};
      });

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
    });

    it('does not write caps probed against a url that has since changed', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps.mockImplementationOnce(async () => {
        serverStore.updateServer(id, {url: 'http://localhost:9090'});
        return {contextLength: 8192, supportsVision: true};
      });

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
    });

    it('issues no request at all for a non-llama.cpp server', async () => {
      const id = serverStore.addServer({
        name: 'LM Studio',
        url: 'http://localhost:1234',
        serverType: 'LM Studio',
      });
      jest.clearAllMocks();

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).not.toHaveBeenCalled();
      expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();
    });

    it('issues no request for a server that no longer exists', async () => {
      jest.clearAllMocks();

      await serverStore.fetchRemoteModelCaps('gone', 'm');

      expect(mockedFetchServerProps).not.toHaveBeenCalled();
    });

    it('drops caps for a removed server, keeping other servers entries', () => {
      const id = addLlamaServer();
      runInAction(() => {
        serverStore.remoteCaps[`${id}/m1`] = {contextLength: 4096};
        serverStore.remoteCaps['other-server/m2'] = {contextLength: 2048};
      });

      serverStore.removeServer(id);

      expect(serverStore.remoteCaps[`${id}/m1`]).toBeUndefined();
      expect(serverStore.remoteCaps['other-server/m2']).toBeDefined();
    });

    it('writes one record from one response, under one url', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({
        contextLength: 8192,
        supportsVision: true,
        samplerDefaults: {top_k: 40},
      });

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]).toEqual({
        contextLength: 8192,
        supportsVision: true,
        samplerDefaults: {top_k: 40},
        probedUrl: 'http://localhost:8080',
      });
    });

    it('keeps a known capability when a placeholder body follows', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      mockedFetchServerProps
        .mockResolvedValueOnce({contextLength: 8192, supportsVision: true})
        .mockResolvedValueOnce({});

      await serverStore.fetchRemoteModelCaps(id, 'm');
      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]?.supportsVision).toBe(true);
    });

    it('writes nothing when a repeat probe reports the same answer', async () => {
      const id = addLlamaServer();
      jest.clearAllMocks();
      const answer = () => ({
        contextLength: 8192,
        supportsVision: true,
        samplerDefaults: {top_k: 40},
      });
      mockedFetchServerProps
        .mockResolvedValueOnce(answer())
        .mockResolvedValueOnce(answer());

      await serverStore.fetchRemoteModelCaps(id, 'm');
      const caps = serverStore.remoteCaps[`${id}/m`];

      await serverStore.fetchRemoteModelCaps(id, 'm');

      // Same object, not merely an equal one: a rewrite would wake every
      // observer for an answer that said nothing new.
      expect(serverStore.remoteCaps[`${id}/m`]).toBe(caps);
    });

    it('issues no bare retry once the scoped answer resolved a field', async () => {
      const id = addLlamaServer();
      runInAction(() => {
        serverStore.serverModels.set(id, [
          {id: 'm', object: 'model', owned_by: 'system'},
        ]);
      });
      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({
        samplerDefaults: {top_k: 40},
      });

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(mockedFetchServerProps).toHaveBeenCalledTimes(1);
      expect(serverStore.remoteCaps[`${id}/m`]?.samplerDefaults).toEqual({
        top_k: 40,
      });
    });

    it('reads a store hydrated without sampler defaults as unknown, then fills them', async () => {
      const id = addLlamaServer();

      expect(serverStore.remoteCaps[`${id}/m`]).toBeUndefined();

      jest.clearAllMocks();
      mockedFetchServerProps.mockResolvedValueOnce({
        samplerDefaults: {top_k: 40},
      });

      await serverStore.fetchRemoteModelCaps(id, 'm');

      expect(serverStore.remoteCaps[`${id}/m`]?.samplerDefaults).toEqual({
        top_k: 40,
      });
    });
  });
});
